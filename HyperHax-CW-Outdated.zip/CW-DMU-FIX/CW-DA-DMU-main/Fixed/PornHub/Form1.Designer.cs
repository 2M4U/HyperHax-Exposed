﻿
namespace PornHub
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Panel_LeftSide = new System.Windows.Forms.Panel();
            this.Btn_Discord_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.Btn_P4_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Btn_P3_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Btn_P2_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Btn_P1_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Btn_Server_Icon = new FontAwesome.Sharp.IconPictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Btn_Server_BG = new System.Windows.Forms.Panel();
            this.Animations = new System.Windows.Forms.Timer(this.components);
            this.Panel_Server = new System.Windows.Forms.Panel();
            this.CB_AutoKill = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel61 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.bar_noclip = new ReaLTaiizor.Controls.PoisonTrackBar();
            this.CB_Noclip = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel59 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.DAHelp = new System.Windows.Forms.Label();
            this.CB_RoundSkip = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel60 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Btn_TP_Bots = new ReaLTaiizor.Controls.ForeverButton();
            this.CB_Bots = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel58 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Btn_QuickDA = new ReaLTaiizor.Controls.ForeverButton();
            this.Dtn_Diamond = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Kill_multi = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Dark = new ReaLTaiizor.Controls.ForeverButton();
            this.LBL_Shots = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Bar_Shots = new ReaLTaiizor.Controls.PoisonTrackBar();
            this.LBL_Kills = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Bar_Kills = new ReaLTaiizor.Controls.PoisonTrackBar();
            this.Btn_TP_Set = new ReaLTaiizor.Controls.ForeverButton();
            this.CB_TP_ZM = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel57 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Btn_KillAll = new ReaLTaiizor.Controls.ForeverButton();
            this.Form_Header = new System.Windows.Forms.Panel();
            this.Btn_Close = new ReaLTaiizor.Controls.ForeverButton();
            this.Panel_P1 = new System.Windows.Forms.Panel();
            this.nightHeaderLabel1 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_zqinissofuckingsexy_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.CB_Shoot_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel2 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel48 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rainbow_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel37 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel38 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Box_CycleEnd_P1 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_CycleStart_P1 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Btn_TP_P1 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib2_P1 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib_P1 = new ReaLTaiizor.Controls.ForeverButton();
            this.Box_TP_P1 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_Weapons_P1 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.CB_Cycle_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel39 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Croshair_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel40 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rapid_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel41 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Jail_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel42 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Crit_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel43 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Speed_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel44 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Ammo_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel45 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Points_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel46 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_God_P1 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel47 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Panel_P2 = new System.Windows.Forms.Panel();
            this.nightHeaderLabel31 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_zqinissofuckingsexy_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.CB_Shoot_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel32 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel33 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rainbow_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel34 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel35 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Box_CycleEnd_P2 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_CycleStart_P2 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Btn_TP_P2 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib2_P2 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib_P2 = new ReaLTaiizor.Controls.ForeverButton();
            this.Box_TP_P2 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_Weapons_P2 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.CB_Cycle_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel36 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Croshair_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel49 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rapid_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel50 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Jail_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel51 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Crit_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel52 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Speed_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel53 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Ammo_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel54 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Points_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel55 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_God_P2 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel56 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Panel_P3 = new System.Windows.Forms.Panel();
            this.nightHeaderLabel17 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_zqinissofuckingsexy_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.CB_Shoot_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel18 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel19 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rainbow_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel20 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel21 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Box_CycleEnd_P3 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_CycleStart_P3 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Btn_TP_P3 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib2_P3 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib_P3 = new ReaLTaiizor.Controls.ForeverButton();
            this.Box_TP_P3 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_Weapons_P3 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.CB_Cycle_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel22 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Croshair_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel23 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rapid_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel24 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Jail_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel25 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Crit_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel26 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Speed_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel27 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Ammo_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel28 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Points_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel29 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_God_P3 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel30 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Panel_P4 = new System.Windows.Forms.Panel();
            this.nightHeaderLabel3 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_zqinissofuckingsexy_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.CB_Shoot_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel4 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel5 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rainbow_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel6 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.nightHeaderLabel7 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Box_CycleEnd_P4 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_CycleStart_P4 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Btn_TP_P4 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib2_P4 = new ReaLTaiizor.Controls.ForeverButton();
            this.Btn_Gib_P4 = new ReaLTaiizor.Controls.ForeverButton();
            this.Box_TP_P4 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.Box_Weapons_P4 = new ReaLTaiizor.Controls.ForeverComboBox();
            this.CB_Cycle_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel8 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Croshair_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel9 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Rapid_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel10 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Jail_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel11 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Crit_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel12 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Speed_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel13 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Ammo_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel14 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_Points_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel15 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.CB_God_P4 = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel16 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.LBL_PlayerName = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.LBL_Gun = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.XP_Timer = new System.Windows.Forms.Timer(this.components);
            this.CB_XP = new ReaLTaiizor.Controls.MetroSwitch();
            this.nightHeaderLabel62 = new ReaLTaiizor.Controls.NightHeaderLabel();
            this.Panel_LeftSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_Discord_Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P4_Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P3_Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P2_Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P1_Icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_Server_Icon)).BeginInit();
            this.Panel_Server.SuspendLayout();
            this.Form_Header.SuspendLayout();
            this.Panel_P1.SuspendLayout();
            this.Panel_P2.SuspendLayout();
            this.Panel_P3.SuspendLayout();
            this.Panel_P4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel_LeftSide
            // 
            this.Panel_LeftSide.BackColor = System.Drawing.Color.Transparent;
            this.Panel_LeftSide.Controls.Add(this.Btn_Discord_Icon);
            this.Panel_LeftSide.Controls.Add(this.Btn_P4_Icon);
            this.Panel_LeftSide.Controls.Add(this.panel5);
            this.Panel_LeftSide.Controls.Add(this.Btn_P3_Icon);
            this.Panel_LeftSide.Controls.Add(this.panel4);
            this.Panel_LeftSide.Controls.Add(this.Btn_P2_Icon);
            this.Panel_LeftSide.Controls.Add(this.panel3);
            this.Panel_LeftSide.Controls.Add(this.Btn_P1_Icon);
            this.Panel_LeftSide.Controls.Add(this.panel2);
            this.Panel_LeftSide.Controls.Add(this.Btn_Server_Icon);
            this.Panel_LeftSide.Controls.Add(this.panel1);
            this.Panel_LeftSide.Controls.Add(this.Btn_Server_BG);
            this.Panel_LeftSide.Location = new System.Drawing.Point(0, 129);
            this.Panel_LeftSide.Name = "Panel_LeftSide";
            this.Panel_LeftSide.Size = new System.Drawing.Size(100, 500);
            this.Panel_LeftSide.TabIndex = 2;
            // 
            // Btn_Discord_Icon
            // 
            this.Btn_Discord_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Discord_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Discord_Icon.BackgroundImage")));
            this.Btn_Discord_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_Discord_Icon.IconChar = FontAwesome.Sharp.IconChar.Discord;
            this.Btn_Discord_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_Discord_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Discord_Icon.IconSize = 60;
            this.Btn_Discord_Icon.Location = new System.Drawing.Point(20, 428);
            this.Btn_Discord_Icon.Name = "Btn_Discord_Icon";
            this.Btn_Discord_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_Discord_Icon.TabIndex = 8;
            this.Btn_Discord_Icon.TabStop = false;
            this.Btn_Discord_Icon.UseGdi = true;
            this.Btn_Discord_Icon.UseIconCache = true;
            this.Btn_Discord_Icon.Click += new System.EventHandler(this.Btn_Discord_Icon_Click);
            this.Btn_Discord_Icon.MouseEnter += new System.EventHandler(this.Btn_Discord_Icon_MouseEnter);
            this.Btn_Discord_Icon.MouseLeave += new System.EventHandler(this.Btn_Discord_Icon_MouseLeave);
            // 
            // Btn_P4_Icon
            // 
            this.Btn_P4_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_P4_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_P4_Icon.BackgroundImage")));
            this.Btn_P4_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_P4_Icon.IconChar = FontAwesome.Sharp.IconChar.UserTie;
            this.Btn_P4_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_P4_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_P4_Icon.IconSize = 60;
            this.Btn_P4_Icon.Location = new System.Drawing.Point(20, 345);
            this.Btn_P4_Icon.Name = "Btn_P4_Icon";
            this.Btn_P4_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_P4_Icon.TabIndex = 8;
            this.Btn_P4_Icon.TabStop = false;
            this.Btn_P4_Icon.UseGdi = true;
            this.Btn_P4_Icon.UseIconCache = true;
            this.Btn_P4_Icon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_P4_Icon_MouseDown);
            this.Btn_P4_Icon.MouseEnter += new System.EventHandler(this.Btn_P4_Icon_MouseEnter);
            this.Btn_P4_Icon.MouseLeave += new System.EventHandler(this.Btn_P4_Icon_MouseLeave);
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.Location = new System.Drawing.Point(0, 421);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(96, 75);
            this.panel5.TabIndex = 9;
            // 
            // Btn_P3_Icon
            // 
            this.Btn_P3_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_P3_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_P3_Icon.BackgroundImage")));
            this.Btn_P3_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_P3_Icon.IconChar = FontAwesome.Sharp.IconChar.UserSecret;
            this.Btn_P3_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_P3_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_P3_Icon.IconSize = 60;
            this.Btn_P3_Icon.Location = new System.Drawing.Point(20, 262);
            this.Btn_P3_Icon.Name = "Btn_P3_Icon";
            this.Btn_P3_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_P3_Icon.TabIndex = 8;
            this.Btn_P3_Icon.TabStop = false;
            this.Btn_P3_Icon.UseGdi = true;
            this.Btn_P3_Icon.UseIconCache = true;
            this.Btn_P3_Icon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_P3_Icon_MouseDown);
            this.Btn_P3_Icon.MouseEnter += new System.EventHandler(this.Btn_P3_Icon_MouseEnter);
            this.Btn_P3_Icon.MouseLeave += new System.EventHandler(this.Btn_P3_Icon_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.Location = new System.Drawing.Point(0, 338);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(96, 75);
            this.panel4.TabIndex = 9;
            // 
            // Btn_P2_Icon
            // 
            this.Btn_P2_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_P2_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_P2_Icon.BackgroundImage")));
            this.Btn_P2_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_P2_Icon.IconChar = FontAwesome.Sharp.IconChar.UserNinja;
            this.Btn_P2_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_P2_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_P2_Icon.IconSize = 60;
            this.Btn_P2_Icon.Location = new System.Drawing.Point(20, 179);
            this.Btn_P2_Icon.Name = "Btn_P2_Icon";
            this.Btn_P2_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_P2_Icon.TabIndex = 8;
            this.Btn_P2_Icon.TabStop = false;
            this.Btn_P2_Icon.UseGdi = true;
            this.Btn_P2_Icon.UseIconCache = true;
            this.Btn_P2_Icon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_P2_Icon_MouseDown);
            this.Btn_P2_Icon.MouseEnter += new System.EventHandler(this.Btn_P2_Icon_MouseEnter);
            this.Btn_P2_Icon.MouseLeave += new System.EventHandler(this.Btn_P2_Icon_MouseLeave);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Location = new System.Drawing.Point(0, 255);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(96, 75);
            this.panel3.TabIndex = 9;
            // 
            // Btn_P1_Icon
            // 
            this.Btn_P1_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_P1_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_P1_Icon.BackgroundImage")));
            this.Btn_P1_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_P1_Icon.IconChar = FontAwesome.Sharp.IconChar.UserAstronaut;
            this.Btn_P1_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_P1_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_P1_Icon.IconSize = 60;
            this.Btn_P1_Icon.Location = new System.Drawing.Point(20, 96);
            this.Btn_P1_Icon.Name = "Btn_P1_Icon";
            this.Btn_P1_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_P1_Icon.TabIndex = 6;
            this.Btn_P1_Icon.TabStop = false;
            this.Btn_P1_Icon.UseGdi = true;
            this.Btn_P1_Icon.UseIconCache = true;
            this.Btn_P1_Icon.Click += new System.EventHandler(this.Btn_P1_Icon_Click);
            this.Btn_P1_Icon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_P1_Icon_MouseDown);
            this.Btn_P1_Icon.MouseEnter += new System.EventHandler(this.Btn_P1_Icon_MouseEnter);
            this.Btn_P1_Icon.MouseLeave += new System.EventHandler(this.Btn_P1_Icon_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Location = new System.Drawing.Point(0, 172);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(96, 75);
            this.panel2.TabIndex = 9;
            // 
            // Btn_Server_Icon
            // 
            this.Btn_Server_Icon.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Server_Icon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Server_Icon.BackgroundImage")));
            this.Btn_Server_Icon.ForeColor = System.Drawing.Color.Red;
            this.Btn_Server_Icon.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.Btn_Server_Icon.IconColor = System.Drawing.Color.Red;
            this.Btn_Server_Icon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Server_Icon.IconSize = 60;
            this.Btn_Server_Icon.Location = new System.Drawing.Point(20, 13);
            this.Btn_Server_Icon.Name = "Btn_Server_Icon";
            this.Btn_Server_Icon.Size = new System.Drawing.Size(60, 60);
            this.Btn_Server_Icon.TabIndex = 3;
            this.Btn_Server_Icon.TabStop = false;
            this.Btn_Server_Icon.UseGdi = true;
            this.Btn_Server_Icon.UseIconCache = true;
            this.Btn_Server_Icon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_Server_Icon_MouseDown);
            this.Btn_Server_Icon.MouseEnter += new System.EventHandler(this.Btn_Server_Icon_MouseEnter);
            this.Btn_Server_Icon.MouseLeave += new System.EventHandler(this.Btn_Server_Icon_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(0, 89);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(96, 75);
            this.panel1.TabIndex = 7;
            // 
            // Btn_Server_BG
            // 
            this.Btn_Server_BG.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Server_BG.BackgroundImage")));
            this.Btn_Server_BG.Location = new System.Drawing.Point(0, 6);
            this.Btn_Server_BG.Name = "Btn_Server_BG";
            this.Btn_Server_BG.Size = new System.Drawing.Size(96, 75);
            this.Btn_Server_BG.TabIndex = 5;
            // 
            // Animations
            // 
            this.Animations.Enabled = true;
            this.Animations.Interval = 25;
            this.Animations.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Panel_Server
            // 
            this.Panel_Server.BackColor = System.Drawing.Color.Transparent;
            this.Panel_Server.Controls.Add(this.nightHeaderLabel62);
            this.Panel_Server.Controls.Add(this.CB_XP);
            this.Panel_Server.Controls.Add(this.CB_AutoKill);
            this.Panel_Server.Controls.Add(this.nightHeaderLabel61);
            this.Panel_Server.Controls.Add(this.bar_noclip);
            this.Panel_Server.Controls.Add(this.CB_Noclip);
            this.Panel_Server.Controls.Add(this.nightHeaderLabel59);
            this.Panel_Server.Controls.Add(this.DAHelp);
            this.Panel_Server.Controls.Add(this.CB_RoundSkip);
            this.Panel_Server.Controls.Add(this.nightHeaderLabel60);
            this.Panel_Server.Controls.Add(this.Btn_TP_Bots);
            this.Panel_Server.Controls.Add(this.CB_Bots);
            this.Panel_Server.Controls.Add(this.nightHeaderLabel58);
            this.Panel_Server.Controls.Add(this.Btn_QuickDA);
            this.Panel_Server.Controls.Add(this.Dtn_Diamond);
            this.Panel_Server.Controls.Add(this.Btn_Kill_multi);
            this.Panel_Server.Controls.Add(this.Btn_Dark);
            this.Panel_Server.Controls.Add(this.LBL_Shots);
            this.Panel_Server.Controls.Add(this.Bar_Shots);
            this.Panel_Server.Controls.Add(this.LBL_Kills);
            this.Panel_Server.Controls.Add(this.Bar_Kills);
            this.Panel_Server.Controls.Add(this.Btn_TP_Set);
            this.Panel_Server.Controls.Add(this.CB_TP_ZM);
            this.Panel_Server.Controls.Add(this.nightHeaderLabel57);
            this.Panel_Server.Controls.Add(this.Btn_KillAll);
            this.Panel_Server.Location = new System.Drawing.Point(116, 129);
            this.Panel_Server.Name = "Panel_Server";
            this.Panel_Server.Size = new System.Drawing.Size(428, 500);
            this.Panel_Server.TabIndex = 3;
            this.Panel_Server.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Server_Paint);
            // 
            // CB_AutoKill
            // 
            this.CB_AutoKill.BackColor = System.Drawing.Color.Transparent;
            this.CB_AutoKill.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_AutoKill.BorderColor = System.Drawing.Color.White;
            this.CB_AutoKill.CheckColor = System.Drawing.Color.Red;
            this.CB_AutoKill.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_AutoKill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_AutoKill.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_AutoKill.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_AutoKill.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_AutoKill.IsDerivedStyle = false;
            this.CB_AutoKill.Location = new System.Drawing.Point(10, 328);
            this.CB_AutoKill.Margin = new System.Windows.Forms.Padding(9);
            this.CB_AutoKill.Name = "CB_AutoKill";
            this.CB_AutoKill.Size = new System.Drawing.Size(58, 22);
            this.CB_AutoKill.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_AutoKill.StyleManager = null;
            this.CB_AutoKill.Switched = false;
            this.CB_AutoKill.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_AutoKill.TabIndex = 275;
            this.CB_AutoKill.Text = "metroSwitch1";
            this.CB_AutoKill.ThemeAuthor = "Taiizor";
            this.CB_AutoKill.ThemeName = "MetroLight";
            this.CB_AutoKill.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_AutoKill.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_XP_SwitchedChanged);
            // 
            // nightHeaderLabel61
            // 
            this.nightHeaderLabel61.AutoSize = true;
            this.nightHeaderLabel61.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel61.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel61.Location = new System.Drawing.Point(81, 327);
            this.nightHeaderLabel61.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel61.Name = "nightHeaderLabel61";
            this.nightHeaderLabel61.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel61.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel61.Size = new System.Drawing.Size(111, 24);
            this.nightHeaderLabel61.TabIndex = 274;
            this.nightHeaderLabel61.Text = "1 Shot Kill  All";
            this.nightHeaderLabel61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel61.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel61.UseCompatibleTextRendering = true;
            // 
            // bar_noclip
            // 
            this.bar_noclip.BackColor = System.Drawing.Color.Transparent;
            this.bar_noclip.Location = new System.Drawing.Point(144, 463);
            this.bar_noclip.Margin = new System.Windows.Forms.Padding(9);
            this.bar_noclip.Maximum = 75;
            this.bar_noclip.Minimum = 1;
            this.bar_noclip.MouseWheelBarPartitions = 5;
            this.bar_noclip.Name = "bar_noclip";
            this.bar_noclip.Size = new System.Drawing.Size(76, 23);
            this.bar_noclip.TabIndex = 273;
            this.bar_noclip.Theme = ReaLTaiizor.Enum.Poison.ThemeStyle.Dark;
            this.bar_noclip.UseCustomBackColor = true;
            this.bar_noclip.Value = 1;
            // 
            // CB_Noclip
            // 
            this.CB_Noclip.BackColor = System.Drawing.Color.Transparent;
            this.CB_Noclip.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Noclip.BorderColor = System.Drawing.Color.White;
            this.CB_Noclip.CheckColor = System.Drawing.Color.Red;
            this.CB_Noclip.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Noclip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Noclip.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Noclip.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Noclip.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Noclip.IsDerivedStyle = false;
            this.CB_Noclip.Location = new System.Drawing.Point(10, 463);
            this.CB_Noclip.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Noclip.Name = "CB_Noclip";
            this.CB_Noclip.Size = new System.Drawing.Size(58, 22);
            this.CB_Noclip.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Noclip.StyleManager = null;
            this.CB_Noclip.Switched = false;
            this.CB_Noclip.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Noclip.TabIndex = 272;
            this.CB_Noclip.Text = "CB_Noclip";
            this.CB_Noclip.ThemeAuthor = "Taiizor";
            this.CB_Noclip.ThemeName = "MetroLight";
            this.CB_Noclip.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Noclip.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.metroSwitch1_SwitchedChanged_1);
            // 
            // nightHeaderLabel59
            // 
            this.nightHeaderLabel59.AutoSize = true;
            this.nightHeaderLabel59.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel59.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel59.Location = new System.Drawing.Point(81, 462);
            this.nightHeaderLabel59.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel59.Name = "nightHeaderLabel59";
            this.nightHeaderLabel59.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel59.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel59.Size = new System.Drawing.Size(54, 24);
            this.nightHeaderLabel59.TabIndex = 271;
            this.nightHeaderLabel59.Text = "Noclip";
            this.nightHeaderLabel59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel59.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel59.UseCompatibleTextRendering = true;
            // 
            // DAHelp
            // 
            this.DAHelp.AutoSize = true;
            this.DAHelp.BackColor = System.Drawing.Color.Transparent;
            this.DAHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DAHelp.ForeColor = System.Drawing.Color.White;
            this.DAHelp.Location = new System.Drawing.Point(303, 483);
            this.DAHelp.Name = "DAHelp";
            this.DAHelp.Size = new System.Drawing.Size(122, 13);
            this.DAHelp.TabIndex = 221;
            this.DAHelp.Text = "Dark Aether Tutorial";
            this.DAHelp.Click += new System.EventHandler(this.DAHelp_Click);
            // 
            // CB_RoundSkip
            // 
            this.CB_RoundSkip.BackColor = System.Drawing.Color.Transparent;
            this.CB_RoundSkip.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_RoundSkip.BorderColor = System.Drawing.Color.White;
            this.CB_RoundSkip.CheckColor = System.Drawing.Color.Red;
            this.CB_RoundSkip.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_RoundSkip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_RoundSkip.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_RoundSkip.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_RoundSkip.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_RoundSkip.IsDerivedStyle = false;
            this.CB_RoundSkip.Location = new System.Drawing.Point(10, 59);
            this.CB_RoundSkip.Margin = new System.Windows.Forms.Padding(9);
            this.CB_RoundSkip.Name = "CB_RoundSkip";
            this.CB_RoundSkip.Size = new System.Drawing.Size(58, 22);
            this.CB_RoundSkip.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_RoundSkip.StyleManager = null;
            this.CB_RoundSkip.Switched = false;
            this.CB_RoundSkip.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_RoundSkip.TabIndex = 270;
            this.CB_RoundSkip.Text = "metroSwitch1";
            this.CB_RoundSkip.ThemeAuthor = "Taiizor";
            this.CB_RoundSkip.ThemeName = "MetroLight";
            this.CB_RoundSkip.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_RoundSkip.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_RoundSkip_SwitchedChanged);
            // 
            // nightHeaderLabel60
            // 
            this.nightHeaderLabel60.AutoSize = true;
            this.nightHeaderLabel60.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel60.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel60.Location = new System.Drawing.Point(81, 58);
            this.nightHeaderLabel60.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel60.Name = "nightHeaderLabel60";
            this.nightHeaderLabel60.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel60.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel60.Size = new System.Drawing.Size(94, 24);
            this.nightHeaderLabel60.TabIndex = 269;
            this.nightHeaderLabel60.Text = "Round Skip";
            this.nightHeaderLabel60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel60.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel60.UseCompatibleTextRendering = true;
            // 
            // Btn_TP_Bots
            // 
            this.Btn_TP_Bots.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_Bots.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_TP_Bots.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_Bots.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_Bots.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_Bots.ForeColor = System.Drawing.Color.Black;
            this.Btn_TP_Bots.Location = new System.Drawing.Point(243, 422);
            this.Btn_TP_Bots.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_Bots.Name = "Btn_TP_Bots";
            this.Btn_TP_Bots.Rounded = false;
            this.Btn_TP_Bots.Size = new System.Drawing.Size(173, 25);
            this.Btn_TP_Bots.TabIndex = 258;
            this.Btn_TP_Bots.Text = "Set Location";
            this.Btn_TP_Bots.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_TP_Bots.Click += new System.EventHandler(this.Btn_TP_Bots_Click);
            // 
            // CB_Bots
            // 
            this.CB_Bots.BackColor = System.Drawing.Color.Transparent;
            this.CB_Bots.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Bots.BorderColor = System.Drawing.Color.White;
            this.CB_Bots.CheckColor = System.Drawing.Color.Red;
            this.CB_Bots.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Bots.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Bots.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Bots.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Bots.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Bots.IsDerivedStyle = false;
            this.CB_Bots.Location = new System.Drawing.Point(10, 423);
            this.CB_Bots.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Bots.Name = "CB_Bots";
            this.CB_Bots.Size = new System.Drawing.Size(58, 22);
            this.CB_Bots.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Bots.StyleManager = null;
            this.CB_Bots.Switched = false;
            this.CB_Bots.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Bots.TabIndex = 257;
            this.CB_Bots.Text = "metroSwitch1";
            this.CB_Bots.ThemeAuthor = "Taiizor";
            this.CB_Bots.ThemeName = "MetroLight";
            this.CB_Bots.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Bots.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_Bots_SwitchedChanged);
            // 
            // nightHeaderLabel58
            // 
            this.nightHeaderLabel58.AutoSize = true;
            this.nightHeaderLabel58.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel58.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel58.Location = new System.Drawing.Point(81, 422);
            this.nightHeaderLabel58.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel58.Name = "nightHeaderLabel58";
            this.nightHeaderLabel58.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel58.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel58.Size = new System.Drawing.Size(108, 24);
            this.nightHeaderLabel58.TabIndex = 256;
            this.nightHeaderLabel58.Text = "Teleport Bots";
            this.nightHeaderLabel58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel58.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel58.UseCompatibleTextRendering = true;
            // 
            // Btn_QuickDA
            // 
            this.Btn_QuickDA.BackColor = System.Drawing.Color.Transparent;
            this.Btn_QuickDA.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_QuickDA.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_QuickDA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_QuickDA.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_QuickDA.ForeColor = System.Drawing.Color.Black;
            this.Btn_QuickDA.Location = new System.Drawing.Point(238, 243);
            this.Btn_QuickDA.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_QuickDA.Name = "Btn_QuickDA";
            this.Btn_QuickDA.Rounded = false;
            this.Btn_QuickDA.Size = new System.Drawing.Size(181, 25);
            this.Btn_QuickDA.TabIndex = 255;
            this.Btn_QuickDA.Text = "Set Quick DA Settings";
            this.Btn_QuickDA.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_QuickDA.Click += new System.EventHandler(this.Btn_QuickDA_Click);
            // 
            // Dtn_Diamond
            // 
            this.Dtn_Diamond.BackColor = System.Drawing.Color.Transparent;
            this.Dtn_Diamond.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Dtn_Diamond.BaseColor = System.Drawing.Color.Transparent;
            this.Dtn_Diamond.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dtn_Diamond.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dtn_Diamond.ForeColor = System.Drawing.Color.Black;
            this.Dtn_Diamond.Location = new System.Drawing.Point(9, 285);
            this.Dtn_Diamond.Margin = new System.Windows.Forms.Padding(9);
            this.Dtn_Diamond.Name = "Dtn_Diamond";
            this.Dtn_Diamond.Rounded = false;
            this.Dtn_Diamond.Size = new System.Drawing.Size(211, 25);
            this.Dtn_Diamond.TabIndex = 254;
            this.Dtn_Diamond.Text = "Enable MP Instant Diamond";
            this.Dtn_Diamond.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Dtn_Diamond.Click += new System.EventHandler(this.Dtn_Diamond_Click);
            // 
            // Btn_Kill_multi
            // 
            this.Btn_Kill_multi.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Kill_multi.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_Kill_multi.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Kill_multi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Kill_multi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Kill_multi.ForeColor = System.Drawing.Color.Black;
            this.Btn_Kill_multi.Location = new System.Drawing.Point(238, 285);
            this.Btn_Kill_multi.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Kill_multi.Name = "Btn_Kill_multi";
            this.Btn_Kill_multi.Rounded = false;
            this.Btn_Kill_multi.Size = new System.Drawing.Size(181, 25);
            this.Btn_Kill_multi.TabIndex = 253;
            this.Btn_Kill_multi.Text = "Enable Kill Multiplier";
            this.Btn_Kill_multi.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_Kill_multi.Click += new System.EventHandler(this.Btn_Kill_multi_Click);
            // 
            // Btn_Dark
            // 
            this.Btn_Dark.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Dark.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_Dark.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Dark.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Dark.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Dark.ForeColor = System.Drawing.Color.Black;
            this.Btn_Dark.Location = new System.Drawing.Point(9, 243);
            this.Btn_Dark.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Dark.Name = "Btn_Dark";
            this.Btn_Dark.Rounded = false;
            this.Btn_Dark.Size = new System.Drawing.Size(211, 25);
            this.Btn_Dark.TabIndex = 252;
            this.Btn_Dark.Text = "Enable Instant Dark Aether";
            this.Btn_Dark.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_Dark.Click += new System.EventHandler(this.Btn_Dark_Click);
            // 
            // LBL_Shots
            // 
            this.LBL_Shots.AutoSize = true;
            this.LBL_Shots.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Shots.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Shots.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Shots.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Shots.Location = new System.Drawing.Point(119, 103);
            this.LBL_Shots.Margin = new System.Windows.Forms.Padding(9);
            this.LBL_Shots.Name = "LBL_Shots";
            this.LBL_Shots.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.LBL_Shots.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.LBL_Shots.Size = new System.Drawing.Size(183, 24);
            this.LBL_Shots.TabIndex = 251;
            this.LBL_Shots.Text = "Weapon Cycle: 5 Shots";
            this.LBL_Shots.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBL_Shots.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.LBL_Shots.UseCompatibleTextRendering = true;
            // 
            // Bar_Shots
            // 
            this.Bar_Shots.BackColor = System.Drawing.Color.Transparent;
            this.Bar_Shots.LargeChange = 50;
            this.Bar_Shots.Location = new System.Drawing.Point(9, 126);
            this.Bar_Shots.Margin = new System.Windows.Forms.Padding(9);
            this.Bar_Shots.Maximum = 5000;
            this.Bar_Shots.Minimum = 1;
            this.Bar_Shots.MouseWheelBarPartitions = 5;
            this.Bar_Shots.Name = "Bar_Shots";
            this.Bar_Shots.Size = new System.Drawing.Size(410, 23);
            this.Bar_Shots.TabIndex = 250;
            this.Bar_Shots.Theme = ReaLTaiizor.Enum.Poison.ThemeStyle.Dark;
            this.Bar_Shots.UseCustomBackColor = true;
            this.Bar_Shots.Value = 5;
            this.Bar_Shots.ValueChanged += new System.EventHandler(this.Bar_Shots_ValueChanged);
            // 
            // LBL_Kills
            // 
            this.LBL_Kills.AutoSize = true;
            this.LBL_Kills.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Kills.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Kills.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Kills.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Kills.Location = new System.Drawing.Point(121, 170);
            this.LBL_Kills.Margin = new System.Windows.Forms.Padding(9);
            this.LBL_Kills.Name = "LBL_Kills";
            this.LBL_Kills.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.LBL_Kills.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.LBL_Kills.Size = new System.Drawing.Size(172, 24);
            this.LBL_Kills.TabIndex = 249;
            this.LBL_Kills.Text = "Weapon Cycle: 5 Kills";
            this.LBL_Kills.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBL_Kills.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.LBL_Kills.UseCompatibleTextRendering = true;
            // 
            // Bar_Kills
            // 
            this.Bar_Kills.BackColor = System.Drawing.Color.Transparent;
            this.Bar_Kills.LargeChange = 50;
            this.Bar_Kills.Location = new System.Drawing.Point(10, 192);
            this.Bar_Kills.Margin = new System.Windows.Forms.Padding(9);
            this.Bar_Kills.Maximum = 50;
            this.Bar_Kills.Minimum = 1;
            this.Bar_Kills.MouseWheelBarPartitions = 5;
            this.Bar_Kills.Name = "Bar_Kills";
            this.Bar_Kills.Size = new System.Drawing.Size(409, 23);
            this.Bar_Kills.TabIndex = 248;
            this.Bar_Kills.Theme = ReaLTaiizor.Enum.Poison.ThemeStyle.Dark;
            this.Bar_Kills.UseCustomBackColor = true;
            this.Bar_Kills.Value = 5;
            this.Bar_Kills.ValueChanged += new System.EventHandler(this.Bar_Kills_ValueChanged);
            this.Bar_Kills.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Bar_Kills_Scroll);
            // 
            // Btn_TP_Set
            // 
            this.Btn_TP_Set.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_Set.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_TP_Set.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_Set.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_Set.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_Set.ForeColor = System.Drawing.Color.Black;
            this.Btn_TP_Set.Location = new System.Drawing.Point(243, 381);
            this.Btn_TP_Set.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_Set.Name = "Btn_TP_Set";
            this.Btn_TP_Set.Rounded = false;
            this.Btn_TP_Set.Size = new System.Drawing.Size(173, 25);
            this.Btn_TP_Set.TabIndex = 247;
            this.Btn_TP_Set.Text = "Set Location";
            this.Btn_TP_Set.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_TP_Set.Click += new System.EventHandler(this.Btn_TP_Set_Click);
            // 
            // CB_TP_ZM
            // 
            this.CB_TP_ZM.BackColor = System.Drawing.Color.Transparent;
            this.CB_TP_ZM.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_TP_ZM.BorderColor = System.Drawing.Color.White;
            this.CB_TP_ZM.CheckColor = System.Drawing.Color.Red;
            this.CB_TP_ZM.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_TP_ZM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_TP_ZM.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_TP_ZM.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_TP_ZM.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_TP_ZM.IsDerivedStyle = false;
            this.CB_TP_ZM.Location = new System.Drawing.Point(10, 382);
            this.CB_TP_ZM.Margin = new System.Windows.Forms.Padding(9);
            this.CB_TP_ZM.Name = "CB_TP_ZM";
            this.CB_TP_ZM.Size = new System.Drawing.Size(58, 22);
            this.CB_TP_ZM.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_TP_ZM.StyleManager = null;
            this.CB_TP_ZM.Switched = false;
            this.CB_TP_ZM.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_TP_ZM.TabIndex = 246;
            this.CB_TP_ZM.Text = "metroSwitch1";
            this.CB_TP_ZM.ThemeAuthor = "Taiizor";
            this.CB_TP_ZM.ThemeName = "MetroLight";
            this.CB_TP_ZM.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_TP_ZM.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_TP_ZM_SwitchedChanged);
            // 
            // nightHeaderLabel57
            // 
            this.nightHeaderLabel57.AutoSize = true;
            this.nightHeaderLabel57.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel57.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel57.Location = new System.Drawing.Point(81, 381);
            this.nightHeaderLabel57.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel57.Name = "nightHeaderLabel57";
            this.nightHeaderLabel57.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel57.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel57.Size = new System.Drawing.Size(139, 24);
            this.nightHeaderLabel57.TabIndex = 245;
            this.nightHeaderLabel57.Text = "Teleport Zombies";
            this.nightHeaderLabel57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel57.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel57.UseCompatibleTextRendering = true;
            // 
            // Btn_KillAll
            // 
            this.Btn_KillAll.BackColor = System.Drawing.Color.Transparent;
            this.Btn_KillAll.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_KillAll.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_KillAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_KillAll.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_KillAll.ForeColor = System.Drawing.Color.Black;
            this.Btn_KillAll.Location = new System.Drawing.Point(9, 9);
            this.Btn_KillAll.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_KillAll.Name = "Btn_KillAll";
            this.Btn_KillAll.Rounded = false;
            this.Btn_KillAll.Size = new System.Drawing.Size(410, 25);
            this.Btn_KillAll.TabIndex = 172;
            this.Btn_KillAll.Text = "SAFE END MATCH";
            this.Btn_KillAll.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.Btn_KillAll.Click += new System.EventHandler(this.Btn_KillAll_Click);
            // 
            // Form_Header
            // 
            this.Form_Header.BackColor = System.Drawing.Color.Transparent;
            this.Form_Header.Controls.Add(this.Btn_Close);
            this.Form_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Form_Header.Location = new System.Drawing.Point(0, 0);
            this.Form_Header.Name = "Form_Header";
            this.Form_Header.Size = new System.Drawing.Size(560, 64);
            this.Form_Header.TabIndex = 171;
            this.Form_Header.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form_Header_MouseDown);
            this.Form_Header.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form_Header_MouseMove);
            this.Form_Header.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form_Header_MouseUp);
            // 
            // Btn_Close
            // 
            this.Btn_Close.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Close.BackgroundImage = global::PornHub.Properties.Resources.zqinithian2;
            this.Btn_Close.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Close.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Close.Location = new System.Drawing.Point(516, 12);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Rounded = false;
            this.Btn_Close.Size = new System.Drawing.Size(32, 32);
            this.Btn_Close.TabIndex = 166;
            this.Btn_Close.Text = "✖";
            this.Btn_Close.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Panel_P1
            // 
            this.Panel_P1.BackColor = System.Drawing.Color.Transparent;
            this.Panel_P1.Controls.Add(this.nightHeaderLabel1);
            this.Panel_P1.Controls.Add(this.CB_zqinissofuckingsexy_P1);
            this.Panel_P1.Controls.Add(this.CB_Shoot_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel2);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel48);
            this.Panel_P1.Controls.Add(this.CB_Rainbow_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel37);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel38);
            this.Panel_P1.Controls.Add(this.Box_CycleEnd_P1);
            this.Panel_P1.Controls.Add(this.Box_CycleStart_P1);
            this.Panel_P1.Controls.Add(this.Btn_TP_P1);
            this.Panel_P1.Controls.Add(this.Btn_Gib2_P1);
            this.Panel_P1.Controls.Add(this.Btn_Gib_P1);
            this.Panel_P1.Controls.Add(this.Box_TP_P1);
            this.Panel_P1.Controls.Add(this.Box_Weapons_P1);
            this.Panel_P1.Controls.Add(this.CB_Cycle_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel39);
            this.Panel_P1.Controls.Add(this.CB_Croshair_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel40);
            this.Panel_P1.Controls.Add(this.CB_Rapid_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel41);
            this.Panel_P1.Controls.Add(this.CB_Jail_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel42);
            this.Panel_P1.Controls.Add(this.CB_Crit_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel43);
            this.Panel_P1.Controls.Add(this.CB_Speed_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel44);
            this.Panel_P1.Controls.Add(this.CB_Ammo_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel45);
            this.Panel_P1.Controls.Add(this.CB_Points_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel46);
            this.Panel_P1.Controls.Add(this.CB_God_P1);
            this.Panel_P1.Controls.Add(this.nightHeaderLabel47);
            this.Panel_P1.Location = new System.Drawing.Point(116, 129);
            this.Panel_P1.Name = "Panel_P1";
            this.Panel_P1.Size = new System.Drawing.Size(428, 500);
            this.Panel_P1.TabIndex = 173;
            // 
            // nightHeaderLabel1
            // 
            this.nightHeaderLabel1.AutoSize = true;
            this.nightHeaderLabel1.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel1.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel1.Location = new System.Drawing.Point(288, 212);
            this.nightHeaderLabel1.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel1.Name = "nightHeaderLabel1";
            this.nightHeaderLabel1.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel1.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel1.Size = new System.Drawing.Size(40, 24);
            this.nightHeaderLabel1.TabIndex = 242;
            this.nightHeaderLabel1.Text = "TBD";
            this.nightHeaderLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel1.UseCompatibleTextRendering = true;
            // 
            // CB_zqinissofuckingsexy_P1
            // 
            this.CB_zqinissofuckingsexy_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_zqinissofuckingsexy_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_zqinissofuckingsexy_P1.BorderColor = System.Drawing.Color.White;
            this.CB_zqinissofuckingsexy_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_zqinissofuckingsexy_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_zqinissofuckingsexy_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_zqinissofuckingsexy_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_zqinissofuckingsexy_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P1.IsDerivedStyle = false;
            this.CB_zqinissofuckingsexy_P1.Location = new System.Drawing.Point(218, 212);
            this.CB_zqinissofuckingsexy_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_zqinissofuckingsexy_P1.Name = "CB_zqinissofuckingsexy_P1";
            this.CB_zqinissofuckingsexy_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_zqinissofuckingsexy_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_zqinissofuckingsexy_P1.StyleManager = null;
            this.CB_zqinissofuckingsexy_P1.Switched = false;
            this.CB_zqinissofuckingsexy_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_zqinissofuckingsexy_P1.TabIndex = 241;
            this.CB_zqinissofuckingsexy_P1.Text = "metroSwitch7";
            this.CB_zqinissofuckingsexy_P1.ThemeAuthor = "Taiizor";
            this.CB_zqinissofuckingsexy_P1.ThemeName = "MetroLight";
            this.CB_zqinissofuckingsexy_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // CB_Shoot_P1
            // 
            this.CB_Shoot_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Shoot_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Shoot_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Shoot_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Shoot_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Shoot_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Shoot_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Shoot_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P1.IsDerivedStyle = false;
            this.CB_Shoot_P1.Location = new System.Drawing.Point(10, 212);
            this.CB_Shoot_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Shoot_P1.Name = "CB_Shoot_P1";
            this.CB_Shoot_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Shoot_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Shoot_P1.StyleManager = null;
            this.CB_Shoot_P1.Switched = false;
            this.CB_Shoot_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Shoot_P1.TabIndex = 240;
            this.CB_Shoot_P1.Text = "metroSwitch10";
            this.CB_Shoot_P1.ThemeAuthor = "Taiizor";
            this.CB_Shoot_P1.ThemeName = "MetroLight";
            this.CB_Shoot_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel2
            // 
            this.nightHeaderLabel2.AutoSize = true;
            this.nightHeaderLabel2.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel2.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel2.Location = new System.Drawing.Point(80, 211);
            this.nightHeaderLabel2.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel2.Name = "nightHeaderLabel2";
            this.nightHeaderLabel2.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel2.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel2.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel2.TabIndex = 239;
            this.nightHeaderLabel2.Text = "Auto Shoot";
            this.nightHeaderLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel2.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel48
            // 
            this.nightHeaderLabel48.AutoSize = true;
            this.nightHeaderLabel48.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel48.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel48.Location = new System.Drawing.Point(288, 172);
            this.nightHeaderLabel48.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel48.Name = "nightHeaderLabel48";
            this.nightHeaderLabel48.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel48.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel48.Size = new System.Drawing.Size(109, 24);
            this.nightHeaderLabel48.TabIndex = 238;
            this.nightHeaderLabel48.Text = "Rainbow Gun";
            this.nightHeaderLabel48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel48.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel48.UseCompatibleTextRendering = true;
            // 
            // CB_Rainbow_P1
            // 
            this.CB_Rainbow_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rainbow_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rainbow_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Rainbow_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Rainbow_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rainbow_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rainbow_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rainbow_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P1.IsDerivedStyle = false;
            this.CB_Rainbow_P1.Location = new System.Drawing.Point(218, 172);
            this.CB_Rainbow_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rainbow_P1.Name = "CB_Rainbow_P1";
            this.CB_Rainbow_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Rainbow_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rainbow_P1.StyleManager = null;
            this.CB_Rainbow_P1.Switched = false;
            this.CB_Rainbow_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rainbow_P1.TabIndex = 237;
            this.CB_Rainbow_P1.Text = "metroSwitch7";
            this.CB_Rainbow_P1.ThemeAuthor = "Taiizor";
            this.CB_Rainbow_P1.ThemeName = "MetroLight";
            this.CB_Rainbow_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel37
            // 
            this.nightHeaderLabel37.AutoSize = true;
            this.nightHeaderLabel37.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel37.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel37.Location = new System.Drawing.Point(280, 276);
            this.nightHeaderLabel37.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel37.Name = "nightHeaderLabel37";
            this.nightHeaderLabel37.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel37.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel37.Size = new System.Drawing.Size(83, 24);
            this.nightHeaderLabel37.TabIndex = 236;
            this.nightHeaderLabel37.Text = "Cycle End";
            this.nightHeaderLabel37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel37.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel37.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel38
            // 
            this.nightHeaderLabel38.AutoSize = true;
            this.nightHeaderLabel38.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel38.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel38.Location = new System.Drawing.Point(60, 279);
            this.nightHeaderLabel38.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel38.Name = "nightHeaderLabel38";
            this.nightHeaderLabel38.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel38.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel38.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel38.TabIndex = 235;
            this.nightHeaderLabel38.Text = "Cycle Start";
            this.nightHeaderLabel38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel38.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel38.UseCompatibleTextRendering = true;
            // 
            // Box_CycleEnd_P1
            // 
            this.Box_CycleEnd_P1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleEnd_P1.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleEnd_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleEnd_P1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleEnd_P1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleEnd_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleEnd_P1.ForeColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P1.FormattingEnabled = true;
            this.Box_CycleEnd_P1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleEnd_P1.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P1.ItemHeight = 20;
            this.Box_CycleEnd_P1.Location = new System.Drawing.Point(226, 318);
            this.Box_CycleEnd_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleEnd_P1.Name = "Box_CycleEnd_P1";
            this.Box_CycleEnd_P1.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleEnd_P1.TabIndex = 234;
            // 
            // Box_CycleStart_P1
            // 
            this.Box_CycleStart_P1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleStart_P1.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleStart_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleStart_P1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleStart_P1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleStart_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleStart_P1.ForeColor = System.Drawing.Color.White;
            this.Box_CycleStart_P1.FormattingEnabled = true;
            this.Box_CycleStart_P1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleStart_P1.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleStart_P1.ItemHeight = 20;
            this.Box_CycleStart_P1.Location = new System.Drawing.Point(10, 318);
            this.Box_CycleStart_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleStart_P1.Name = "Box_CycleStart_P1";
            this.Box_CycleStart_P1.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleStart_P1.TabIndex = 233;
            // 
            // Btn_TP_P1
            // 
            this.Btn_TP_P1.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_TP_P1.BackgroundImage")));
            this.Btn_TP_P1.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_P1.Location = new System.Drawing.Point(10, 358);
            this.Btn_TP_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_P1.Name = "Btn_TP_P1";
            this.Btn_TP_P1.Rounded = false;
            this.Btn_TP_P1.Size = new System.Drawing.Size(406, 25);
            this.Btn_TP_P1.TabIndex = 232;
            this.Btn_TP_P1.Text = "Teleport To Location ↓";
            this.Btn_TP_P1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_TP_P1.Click += new System.EventHandler(this.Btn_TP_P1_Click);
            // 
            // Btn_Gib2_P1
            // 
            this.Btn_Gib2_P1.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib2_P1.BackgroundImage")));
            this.Btn_Gib2_P1.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib2_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib2_P1.Location = new System.Drawing.Point(224, 433);
            this.Btn_Gib2_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib2_P1.Name = "Btn_Gib2_P1";
            this.Btn_Gib2_P1.Rounded = false;
            this.Btn_Gib2_P1.Size = new System.Drawing.Size(192, 25);
            this.Btn_Gib2_P1.TabIndex = 231;
            this.Btn_Gib2_P1.Text = "Give Weapon 2 ↓";
            this.Btn_Gib2_P1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib2_P1.Click += new System.EventHandler(this.Btn_Gib2_P1_Click);
            // 
            // Btn_Gib_P1
            // 
            this.Btn_Gib_P1.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib_P1.BackgroundImage")));
            this.Btn_Gib_P1.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib_P1.Location = new System.Drawing.Point(10, 433);
            this.Btn_Gib_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib_P1.Name = "Btn_Gib_P1";
            this.Btn_Gib_P1.Rounded = false;
            this.Btn_Gib_P1.Size = new System.Drawing.Size(200, 25);
            this.Btn_Gib_P1.TabIndex = 230;
            this.Btn_Gib_P1.Text = "Give Weapon 1 ↓";
            this.Btn_Gib_P1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib_P1.Click += new System.EventHandler(this.Btn_Gib_P1_Click);
            // 
            // Box_TP_P1
            // 
            this.Box_TP_P1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_TP_P1.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_TP_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_TP_P1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_TP_P1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_TP_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_TP_P1.ForeColor = System.Drawing.Color.White;
            this.Box_TP_P1.FormattingEnabled = true;
            this.Box_TP_P1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_TP_P1.HoverFontColor = System.Drawing.Color.White;
            this.Box_TP_P1.ItemHeight = 20;
            this.Box_TP_P1.Items.AddRange(new object[] {
            "Spawn",
            "Nacht",
            "Pond",
            "Power"});
            this.Box_TP_P1.Location = new System.Drawing.Point(10, 395);
            this.Box_TP_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Box_TP_P1.Name = "Box_TP_P1";
            this.Box_TP_P1.Size = new System.Drawing.Size(406, 26);
            this.Box_TP_P1.TabIndex = 229;
            // 
            // Box_Weapons_P1
            // 
            this.Box_Weapons_P1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_Weapons_P1.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_Weapons_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_Weapons_P1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_Weapons_P1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_Weapons_P1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_Weapons_P1.ForeColor = System.Drawing.Color.White;
            this.Box_Weapons_P1.FormattingEnabled = true;
            this.Box_Weapons_P1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_Weapons_P1.HoverFontColor = System.Drawing.Color.White;
            this.Box_Weapons_P1.ItemHeight = 20;
            this.Box_Weapons_P1.Location = new System.Drawing.Point(10, 464);
            this.Box_Weapons_P1.Margin = new System.Windows.Forms.Padding(9);
            this.Box_Weapons_P1.Name = "Box_Weapons_P1";
            this.Box_Weapons_P1.Size = new System.Drawing.Size(406, 26);
            this.Box_Weapons_P1.TabIndex = 228;
            // 
            // CB_Cycle_P1
            // 
            this.CB_Cycle_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Cycle_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Cycle_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Cycle_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Cycle_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Cycle_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Cycle_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Cycle_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P1.IsDerivedStyle = false;
            this.CB_Cycle_P1.Location = new System.Drawing.Point(10, 172);
            this.CB_Cycle_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Cycle_P1.Name = "CB_Cycle_P1";
            this.CB_Cycle_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Cycle_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Cycle_P1.StyleManager = null;
            this.CB_Cycle_P1.Switched = false;
            this.CB_Cycle_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Cycle_P1.TabIndex = 227;
            this.CB_Cycle_P1.Text = "metroSwitch10";
            this.CB_Cycle_P1.ThemeAuthor = "Taiizor";
            this.CB_Cycle_P1.ThemeName = "MetroLight";
            this.CB_Cycle_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Cycle_P1.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_Cycle_P1_SwitchedChanged);
            // 
            // nightHeaderLabel39
            // 
            this.nightHeaderLabel39.AutoSize = true;
            this.nightHeaderLabel39.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel39.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel39.Location = new System.Drawing.Point(80, 171);
            this.nightHeaderLabel39.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel39.Name = "nightHeaderLabel39";
            this.nightHeaderLabel39.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel39.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel39.Size = new System.Drawing.Size(117, 24);
            this.nightHeaderLabel39.TabIndex = 226;
            this.nightHeaderLabel39.Text = "Weapon Cycle";
            this.nightHeaderLabel39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel39.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel39.UseCompatibleTextRendering = true;
            // 
            // CB_Croshair_P1
            // 
            this.CB_Croshair_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Croshair_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Croshair_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Croshair_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Croshair_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Croshair_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Croshair_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Croshair_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P1.IsDerivedStyle = false;
            this.CB_Croshair_P1.Location = new System.Drawing.Point(218, 132);
            this.CB_Croshair_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Croshair_P1.Name = "CB_Croshair_P1";
            this.CB_Croshair_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Croshair_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Croshair_P1.StyleManager = null;
            this.CB_Croshair_P1.Switched = false;
            this.CB_Croshair_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Croshair_P1.TabIndex = 225;
            this.CB_Croshair_P1.Text = "metroSwitch7";
            this.CB_Croshair_P1.ThemeAuthor = "Taiizor";
            this.CB_Croshair_P1.ThemeName = "MetroLight";
            this.CB_Croshair_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel40
            // 
            this.nightHeaderLabel40.AutoSize = true;
            this.nightHeaderLabel40.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel40.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel40.Location = new System.Drawing.Point(288, 131);
            this.nightHeaderLabel40.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel40.Name = "nightHeaderLabel40";
            this.nightHeaderLabel40.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel40.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel40.Size = new System.Drawing.Size(133, 24);
            this.nightHeaderLabel40.TabIndex = 224;
            this.nightHeaderLabel40.Text = "ZM To Crosshair";
            this.nightHeaderLabel40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel40.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel40.UseCompatibleTextRendering = true;
            // 
            // CB_Rapid_P1
            // 
            this.CB_Rapid_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rapid_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rapid_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Rapid_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Rapid_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rapid_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rapid_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rapid_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P1.IsDerivedStyle = false;
            this.CB_Rapid_P1.Location = new System.Drawing.Point(10, 132);
            this.CB_Rapid_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rapid_P1.Name = "CB_Rapid_P1";
            this.CB_Rapid_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Rapid_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rapid_P1.StyleManager = null;
            this.CB_Rapid_P1.Switched = false;
            this.CB_Rapid_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rapid_P1.TabIndex = 223;
            this.CB_Rapid_P1.Text = "metroSwitch8";
            this.CB_Rapid_P1.ThemeAuthor = "Taiizor";
            this.CB_Rapid_P1.ThemeName = "MetroLight";
            this.CB_Rapid_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel41
            // 
            this.nightHeaderLabel41.AutoSize = true;
            this.nightHeaderLabel41.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel41.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel41.Location = new System.Drawing.Point(80, 131);
            this.nightHeaderLabel41.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel41.Name = "nightHeaderLabel41";
            this.nightHeaderLabel41.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel41.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel41.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel41.TabIndex = 222;
            this.nightHeaderLabel41.Text = "Rapid Fire";
            this.nightHeaderLabel41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel41.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel41.UseCompatibleTextRendering = true;
            // 
            // CB_Jail_P1
            // 
            this.CB_Jail_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Jail_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Jail_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Jail_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Jail_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Jail_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Jail_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Jail_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P1.IsDerivedStyle = false;
            this.CB_Jail_P1.Location = new System.Drawing.Point(218, 92);
            this.CB_Jail_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Jail_P1.Name = "CB_Jail_P1";
            this.CB_Jail_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Jail_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Jail_P1.StyleManager = null;
            this.CB_Jail_P1.Switched = false;
            this.CB_Jail_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Jail_P1.TabIndex = 221;
            this.CB_Jail_P1.Text = "metroSwitch5";
            this.CB_Jail_P1.ThemeAuthor = "Taiizor";
            this.CB_Jail_P1.ThemeName = "MetroLight";
            this.CB_Jail_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel42
            // 
            this.nightHeaderLabel42.AutoSize = true;
            this.nightHeaderLabel42.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel42.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel42.Location = new System.Drawing.Point(288, 91);
            this.nightHeaderLabel42.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel42.Name = "nightHeaderLabel42";
            this.nightHeaderLabel42.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel42.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel42.Size = new System.Drawing.Size(101, 24);
            this.nightHeaderLabel42.TabIndex = 220;
            this.nightHeaderLabel42.Text = "Send To Jail";
            this.nightHeaderLabel42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel42.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel42.UseCompatibleTextRendering = true;
            // 
            // CB_Crit_P1
            // 
            this.CB_Crit_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Crit_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Crit_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Crit_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Crit_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Crit_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Crit_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Crit_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P1.IsDerivedStyle = false;
            this.CB_Crit_P1.Location = new System.Drawing.Point(10, 92);
            this.CB_Crit_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Crit_P1.Name = "CB_Crit_P1";
            this.CB_Crit_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Crit_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Crit_P1.StyleManager = null;
            this.CB_Crit_P1.Switched = false;
            this.CB_Crit_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Crit_P1.TabIndex = 219;
            this.CB_Crit_P1.Text = "metroSwitch6";
            this.CB_Crit_P1.ThemeAuthor = "Taiizor";
            this.CB_Crit_P1.ThemeName = "MetroLight";
            this.CB_Crit_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel43
            // 
            this.nightHeaderLabel43.AutoSize = true;
            this.nightHeaderLabel43.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel43.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel43.Location = new System.Drawing.Point(80, 91);
            this.nightHeaderLabel43.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel43.Name = "nightHeaderLabel43";
            this.nightHeaderLabel43.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel43.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel43.Size = new System.Drawing.Size(116, 24);
            this.nightHeaderLabel43.TabIndex = 218;
            this.nightHeaderLabel43.Text = "100% Criticals";
            this.nightHeaderLabel43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel43.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel43.UseCompatibleTextRendering = true;
            // 
            // CB_Speed_P1
            // 
            this.CB_Speed_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Speed_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Speed_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Speed_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Speed_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Speed_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Speed_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Speed_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P1.IsDerivedStyle = false;
            this.CB_Speed_P1.Location = new System.Drawing.Point(218, 52);
            this.CB_Speed_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Speed_P1.Name = "CB_Speed_P1";
            this.CB_Speed_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Speed_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Speed_P1.StyleManager = null;
            this.CB_Speed_P1.Switched = false;
            this.CB_Speed_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Speed_P1.TabIndex = 217;
            this.CB_Speed_P1.Text = "metroSwitch3";
            this.CB_Speed_P1.ThemeAuthor = "Taiizor";
            this.CB_Speed_P1.ThemeName = "MetroLight";
            this.CB_Speed_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel44
            // 
            this.nightHeaderLabel44.AutoSize = true;
            this.nightHeaderLabel44.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel44.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel44.Location = new System.Drawing.Point(288, 51);
            this.nightHeaderLabel44.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel44.Name = "nightHeaderLabel44";
            this.nightHeaderLabel44.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel44.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel44.Size = new System.Drawing.Size(98, 24);
            this.nightHeaderLabel44.TabIndex = 216;
            this.nightHeaderLabel44.Text = "Speed Hack";
            this.nightHeaderLabel44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel44.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel44.UseCompatibleTextRendering = true;
            // 
            // CB_Ammo_P1
            // 
            this.CB_Ammo_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Ammo_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Ammo_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Ammo_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Ammo_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Ammo_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Ammo_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Ammo_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P1.IsDerivedStyle = false;
            this.CB_Ammo_P1.Location = new System.Drawing.Point(10, 52);
            this.CB_Ammo_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Ammo_P1.Name = "CB_Ammo_P1";
            this.CB_Ammo_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Ammo_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Ammo_P1.StyleManager = null;
            this.CB_Ammo_P1.Switched = false;
            this.CB_Ammo_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Ammo_P1.TabIndex = 215;
            this.CB_Ammo_P1.Text = "metroSwitch4";
            this.CB_Ammo_P1.ThemeAuthor = "Taiizor";
            this.CB_Ammo_P1.ThemeName = "MetroLight";
            this.CB_Ammo_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel45
            // 
            this.nightHeaderLabel45.AutoSize = true;
            this.nightHeaderLabel45.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel45.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel45.Location = new System.Drawing.Point(80, 51);
            this.nightHeaderLabel45.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel45.Name = "nightHeaderLabel45";
            this.nightHeaderLabel45.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel45.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel45.Size = new System.Drawing.Size(131, 24);
            this.nightHeaderLabel45.TabIndex = 214;
            this.nightHeaderLabel45.Text = "Unlimited Ammo";
            this.nightHeaderLabel45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel45.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel45.UseCompatibleTextRendering = true;
            // 
            // CB_Points_P1
            // 
            this.CB_Points_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_Points_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Points_P1.BorderColor = System.Drawing.Color.White;
            this.CB_Points_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_Points_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Points_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Points_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Points_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P1.IsDerivedStyle = false;
            this.CB_Points_P1.Location = new System.Drawing.Point(218, 12);
            this.CB_Points_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Points_P1.Name = "CB_Points_P1";
            this.CB_Points_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_Points_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Points_P1.StyleManager = null;
            this.CB_Points_P1.Switched = false;
            this.CB_Points_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Points_P1.TabIndex = 213;
            this.CB_Points_P1.Text = "metroSwitch2";
            this.CB_Points_P1.ThemeAuthor = "Taiizor";
            this.CB_Points_P1.ThemeName = "MetroLight";
            this.CB_Points_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel46
            // 
            this.nightHeaderLabel46.AutoSize = true;
            this.nightHeaderLabel46.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel46.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel46.Location = new System.Drawing.Point(288, 11);
            this.nightHeaderLabel46.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel46.Name = "nightHeaderLabel46";
            this.nightHeaderLabel46.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel46.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel46.Size = new System.Drawing.Size(130, 24);
            this.nightHeaderLabel46.TabIndex = 212;
            this.nightHeaderLabel46.Text = "Unlimited Points";
            this.nightHeaderLabel46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel46.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel46.UseCompatibleTextRendering = true;
            // 
            // CB_God_P1
            // 
            this.CB_God_P1.BackColor = System.Drawing.Color.Transparent;
            this.CB_God_P1.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_God_P1.BorderColor = System.Drawing.Color.White;
            this.CB_God_P1.CheckColor = System.Drawing.Color.Red;
            this.CB_God_P1.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_God_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_God_P1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P1.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_God_P1.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P1.IsDerivedStyle = false;
            this.CB_God_P1.Location = new System.Drawing.Point(10, 12);
            this.CB_God_P1.Margin = new System.Windows.Forms.Padding(9);
            this.CB_God_P1.Name = "CB_God_P1";
            this.CB_God_P1.Size = new System.Drawing.Size(58, 22);
            this.CB_God_P1.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_God_P1.StyleManager = null;
            this.CB_God_P1.Switched = false;
            this.CB_God_P1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_God_P1.TabIndex = 211;
            this.CB_God_P1.Text = "metroSwitch1";
            this.CB_God_P1.ThemeAuthor = "Taiizor";
            this.CB_God_P1.ThemeName = "MetroLight";
            this.CB_God_P1.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel47
            // 
            this.nightHeaderLabel47.AutoSize = true;
            this.nightHeaderLabel47.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel47.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel47.Location = new System.Drawing.Point(80, 11);
            this.nightHeaderLabel47.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel47.Name = "nightHeaderLabel47";
            this.nightHeaderLabel47.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel47.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel47.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel47.TabIndex = 210;
            this.nightHeaderLabel47.Text = "God Mode";
            this.nightHeaderLabel47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel47.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel47.UseCompatibleTextRendering = true;
            // 
            // Panel_P2
            // 
            this.Panel_P2.BackColor = System.Drawing.Color.Transparent;
            this.Panel_P2.Controls.Add(this.nightHeaderLabel31);
            this.Panel_P2.Controls.Add(this.CB_zqinissofuckingsexy_P2);
            this.Panel_P2.Controls.Add(this.CB_Shoot_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel32);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel33);
            this.Panel_P2.Controls.Add(this.CB_Rainbow_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel34);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel35);
            this.Panel_P2.Controls.Add(this.Box_CycleEnd_P2);
            this.Panel_P2.Controls.Add(this.Box_CycleStart_P2);
            this.Panel_P2.Controls.Add(this.Btn_TP_P2);
            this.Panel_P2.Controls.Add(this.Btn_Gib2_P2);
            this.Panel_P2.Controls.Add(this.Btn_Gib_P2);
            this.Panel_P2.Controls.Add(this.Box_TP_P2);
            this.Panel_P2.Controls.Add(this.Box_Weapons_P2);
            this.Panel_P2.Controls.Add(this.CB_Cycle_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel36);
            this.Panel_P2.Controls.Add(this.CB_Croshair_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel49);
            this.Panel_P2.Controls.Add(this.CB_Rapid_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel50);
            this.Panel_P2.Controls.Add(this.CB_Jail_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel51);
            this.Panel_P2.Controls.Add(this.CB_Crit_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel52);
            this.Panel_P2.Controls.Add(this.CB_Speed_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel53);
            this.Panel_P2.Controls.Add(this.CB_Ammo_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel54);
            this.Panel_P2.Controls.Add(this.CB_Points_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel55);
            this.Panel_P2.Controls.Add(this.CB_God_P2);
            this.Panel_P2.Controls.Add(this.nightHeaderLabel56);
            this.Panel_P2.Location = new System.Drawing.Point(116, 129);
            this.Panel_P2.Name = "Panel_P2";
            this.Panel_P2.Size = new System.Drawing.Size(428, 500);
            this.Panel_P2.TabIndex = 174;
            // 
            // nightHeaderLabel31
            // 
            this.nightHeaderLabel31.AutoSize = true;
            this.nightHeaderLabel31.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel31.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel31.Location = new System.Drawing.Point(288, 212);
            this.nightHeaderLabel31.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel31.Name = "nightHeaderLabel31";
            this.nightHeaderLabel31.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel31.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel31.Size = new System.Drawing.Size(40, 24);
            this.nightHeaderLabel31.TabIndex = 275;
            this.nightHeaderLabel31.Text = "TBD";
            this.nightHeaderLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel31.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel31.UseCompatibleTextRendering = true;
            // 
            // CB_zqinissofuckingsexy_P2
            // 
            this.CB_zqinissofuckingsexy_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_zqinissofuckingsexy_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_zqinissofuckingsexy_P2.BorderColor = System.Drawing.Color.White;
            this.CB_zqinissofuckingsexy_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_zqinissofuckingsexy_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_zqinissofuckingsexy_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_zqinissofuckingsexy_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_zqinissofuckingsexy_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P2.IsDerivedStyle = false;
            this.CB_zqinissofuckingsexy_P2.Location = new System.Drawing.Point(218, 212);
            this.CB_zqinissofuckingsexy_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_zqinissofuckingsexy_P2.Name = "CB_zqinissofuckingsexy_P2";
            this.CB_zqinissofuckingsexy_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_zqinissofuckingsexy_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_zqinissofuckingsexy_P2.StyleManager = null;
            this.CB_zqinissofuckingsexy_P2.Switched = false;
            this.CB_zqinissofuckingsexy_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_zqinissofuckingsexy_P2.TabIndex = 274;
            this.CB_zqinissofuckingsexy_P2.Text = "metroSwitch7";
            this.CB_zqinissofuckingsexy_P2.ThemeAuthor = "Taiizor";
            this.CB_zqinissofuckingsexy_P2.ThemeName = "MetroLight";
            this.CB_zqinissofuckingsexy_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // CB_Shoot_P2
            // 
            this.CB_Shoot_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Shoot_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Shoot_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Shoot_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Shoot_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Shoot_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Shoot_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Shoot_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P2.IsDerivedStyle = false;
            this.CB_Shoot_P2.Location = new System.Drawing.Point(10, 212);
            this.CB_Shoot_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Shoot_P2.Name = "CB_Shoot_P2";
            this.CB_Shoot_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Shoot_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Shoot_P2.StyleManager = null;
            this.CB_Shoot_P2.Switched = false;
            this.CB_Shoot_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Shoot_P2.TabIndex = 273;
            this.CB_Shoot_P2.Text = "metroSwitch10";
            this.CB_Shoot_P2.ThemeAuthor = "Taiizor";
            this.CB_Shoot_P2.ThemeName = "MetroLight";
            this.CB_Shoot_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel32
            // 
            this.nightHeaderLabel32.AutoSize = true;
            this.nightHeaderLabel32.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel32.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel32.Location = new System.Drawing.Point(80, 211);
            this.nightHeaderLabel32.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel32.Name = "nightHeaderLabel32";
            this.nightHeaderLabel32.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel32.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel32.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel32.TabIndex = 272;
            this.nightHeaderLabel32.Text = "Auto Shoot";
            this.nightHeaderLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel32.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel32.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel33
            // 
            this.nightHeaderLabel33.AutoSize = true;
            this.nightHeaderLabel33.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel33.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel33.Location = new System.Drawing.Point(288, 172);
            this.nightHeaderLabel33.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel33.Name = "nightHeaderLabel33";
            this.nightHeaderLabel33.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel33.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel33.Size = new System.Drawing.Size(109, 24);
            this.nightHeaderLabel33.TabIndex = 271;
            this.nightHeaderLabel33.Text = "Rainbow Gun";
            this.nightHeaderLabel33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel33.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel33.UseCompatibleTextRendering = true;
            // 
            // CB_Rainbow_P2
            // 
            this.CB_Rainbow_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rainbow_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rainbow_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Rainbow_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Rainbow_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rainbow_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rainbow_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rainbow_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P2.IsDerivedStyle = false;
            this.CB_Rainbow_P2.Location = new System.Drawing.Point(218, 172);
            this.CB_Rainbow_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rainbow_P2.Name = "CB_Rainbow_P2";
            this.CB_Rainbow_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Rainbow_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rainbow_P2.StyleManager = null;
            this.CB_Rainbow_P2.Switched = false;
            this.CB_Rainbow_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rainbow_P2.TabIndex = 270;
            this.CB_Rainbow_P2.Text = "metroSwitch7";
            this.CB_Rainbow_P2.ThemeAuthor = "Taiizor";
            this.CB_Rainbow_P2.ThemeName = "MetroLight";
            this.CB_Rainbow_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel34
            // 
            this.nightHeaderLabel34.AutoSize = true;
            this.nightHeaderLabel34.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel34.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel34.Location = new System.Drawing.Point(280, 276);
            this.nightHeaderLabel34.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel34.Name = "nightHeaderLabel34";
            this.nightHeaderLabel34.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel34.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel34.Size = new System.Drawing.Size(83, 24);
            this.nightHeaderLabel34.TabIndex = 269;
            this.nightHeaderLabel34.Text = "Cycle End";
            this.nightHeaderLabel34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel34.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel34.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel35
            // 
            this.nightHeaderLabel35.AutoSize = true;
            this.nightHeaderLabel35.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel35.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel35.Location = new System.Drawing.Point(60, 279);
            this.nightHeaderLabel35.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel35.Name = "nightHeaderLabel35";
            this.nightHeaderLabel35.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel35.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel35.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel35.TabIndex = 268;
            this.nightHeaderLabel35.Text = "Cycle Start";
            this.nightHeaderLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel35.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel35.UseCompatibleTextRendering = true;
            // 
            // Box_CycleEnd_P2
            // 
            this.Box_CycleEnd_P2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleEnd_P2.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleEnd_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleEnd_P2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleEnd_P2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleEnd_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleEnd_P2.ForeColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P2.FormattingEnabled = true;
            this.Box_CycleEnd_P2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleEnd_P2.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P2.ItemHeight = 20;
            this.Box_CycleEnd_P2.Location = new System.Drawing.Point(226, 318);
            this.Box_CycleEnd_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleEnd_P2.Name = "Box_CycleEnd_P2";
            this.Box_CycleEnd_P2.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleEnd_P2.TabIndex = 267;
            // 
            // Box_CycleStart_P2
            // 
            this.Box_CycleStart_P2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleStart_P2.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleStart_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleStart_P2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleStart_P2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleStart_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleStart_P2.ForeColor = System.Drawing.Color.White;
            this.Box_CycleStart_P2.FormattingEnabled = true;
            this.Box_CycleStart_P2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleStart_P2.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleStart_P2.ItemHeight = 20;
            this.Box_CycleStart_P2.Location = new System.Drawing.Point(10, 318);
            this.Box_CycleStart_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleStart_P2.Name = "Box_CycleStart_P2";
            this.Box_CycleStart_P2.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleStart_P2.TabIndex = 266;
            // 
            // Btn_TP_P2
            // 
            this.Btn_TP_P2.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_TP_P2.BackgroundImage")));
            this.Btn_TP_P2.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_P2.Location = new System.Drawing.Point(10, 358);
            this.Btn_TP_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_P2.Name = "Btn_TP_P2";
            this.Btn_TP_P2.Rounded = false;
            this.Btn_TP_P2.Size = new System.Drawing.Size(406, 25);
            this.Btn_TP_P2.TabIndex = 265;
            this.Btn_TP_P2.Text = "Teleport To Location ↓";
            this.Btn_TP_P2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_TP_P2.Click += new System.EventHandler(this.Btn_TP_P2_Click);
            // 
            // Btn_Gib2_P2
            // 
            this.Btn_Gib2_P2.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib2_P2.BackgroundImage")));
            this.Btn_Gib2_P2.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib2_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib2_P2.Location = new System.Drawing.Point(224, 433);
            this.Btn_Gib2_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib2_P2.Name = "Btn_Gib2_P2";
            this.Btn_Gib2_P2.Rounded = false;
            this.Btn_Gib2_P2.Size = new System.Drawing.Size(192, 25);
            this.Btn_Gib2_P2.TabIndex = 264;
            this.Btn_Gib2_P2.Text = "Give Weapon 2 ↓";
            this.Btn_Gib2_P2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib2_P2.Click += new System.EventHandler(this.Btn_Gib2_P2_Click);
            // 
            // Btn_Gib_P2
            // 
            this.Btn_Gib_P2.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib_P2.BackgroundImage")));
            this.Btn_Gib_P2.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib_P2.Location = new System.Drawing.Point(10, 433);
            this.Btn_Gib_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib_P2.Name = "Btn_Gib_P2";
            this.Btn_Gib_P2.Rounded = false;
            this.Btn_Gib_P2.Size = new System.Drawing.Size(200, 25);
            this.Btn_Gib_P2.TabIndex = 263;
            this.Btn_Gib_P2.Text = "Give Weapon 1 ↓";
            this.Btn_Gib_P2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib_P2.Click += new System.EventHandler(this.Btn_Gib_P2_Click);
            // 
            // Box_TP_P2
            // 
            this.Box_TP_P2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_TP_P2.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_TP_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_TP_P2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_TP_P2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_TP_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_TP_P2.ForeColor = System.Drawing.Color.White;
            this.Box_TP_P2.FormattingEnabled = true;
            this.Box_TP_P2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_TP_P2.HoverFontColor = System.Drawing.Color.White;
            this.Box_TP_P2.ItemHeight = 20;
            this.Box_TP_P2.Items.AddRange(new object[] {
            "Spawn",
            "Nacht",
            "Pond",
            "Power"});
            this.Box_TP_P2.Location = new System.Drawing.Point(10, 395);
            this.Box_TP_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Box_TP_P2.Name = "Box_TP_P2";
            this.Box_TP_P2.Size = new System.Drawing.Size(406, 26);
            this.Box_TP_P2.TabIndex = 262;
            // 
            // Box_Weapons_P2
            // 
            this.Box_Weapons_P2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_Weapons_P2.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_Weapons_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_Weapons_P2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_Weapons_P2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_Weapons_P2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_Weapons_P2.ForeColor = System.Drawing.Color.White;
            this.Box_Weapons_P2.FormattingEnabled = true;
            this.Box_Weapons_P2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_Weapons_P2.HoverFontColor = System.Drawing.Color.White;
            this.Box_Weapons_P2.ItemHeight = 20;
            this.Box_Weapons_P2.Location = new System.Drawing.Point(10, 464);
            this.Box_Weapons_P2.Margin = new System.Windows.Forms.Padding(9);
            this.Box_Weapons_P2.Name = "Box_Weapons_P2";
            this.Box_Weapons_P2.Size = new System.Drawing.Size(406, 26);
            this.Box_Weapons_P2.TabIndex = 261;
            // 
            // CB_Cycle_P2
            // 
            this.CB_Cycle_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Cycle_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Cycle_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Cycle_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Cycle_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Cycle_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Cycle_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Cycle_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P2.IsDerivedStyle = false;
            this.CB_Cycle_P2.Location = new System.Drawing.Point(10, 172);
            this.CB_Cycle_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Cycle_P2.Name = "CB_Cycle_P2";
            this.CB_Cycle_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Cycle_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Cycle_P2.StyleManager = null;
            this.CB_Cycle_P2.Switched = false;
            this.CB_Cycle_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Cycle_P2.TabIndex = 260;
            this.CB_Cycle_P2.Text = "metroSwitch10";
            this.CB_Cycle_P2.ThemeAuthor = "Taiizor";
            this.CB_Cycle_P2.ThemeName = "MetroLight";
            this.CB_Cycle_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Cycle_P2.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_Cycle_P2_SwitchedChanged);
            // 
            // nightHeaderLabel36
            // 
            this.nightHeaderLabel36.AutoSize = true;
            this.nightHeaderLabel36.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel36.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel36.Location = new System.Drawing.Point(80, 171);
            this.nightHeaderLabel36.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel36.Name = "nightHeaderLabel36";
            this.nightHeaderLabel36.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel36.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel36.Size = new System.Drawing.Size(117, 24);
            this.nightHeaderLabel36.TabIndex = 259;
            this.nightHeaderLabel36.Text = "Weapon Cycle";
            this.nightHeaderLabel36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel36.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel36.UseCompatibleTextRendering = true;
            // 
            // CB_Croshair_P2
            // 
            this.CB_Croshair_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Croshair_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Croshair_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Croshair_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Croshair_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Croshair_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Croshair_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Croshair_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P2.IsDerivedStyle = false;
            this.CB_Croshair_P2.Location = new System.Drawing.Point(218, 132);
            this.CB_Croshair_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Croshair_P2.Name = "CB_Croshair_P2";
            this.CB_Croshair_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Croshair_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Croshair_P2.StyleManager = null;
            this.CB_Croshair_P2.Switched = false;
            this.CB_Croshair_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Croshair_P2.TabIndex = 258;
            this.CB_Croshair_P2.Text = "metroSwitch7";
            this.CB_Croshair_P2.ThemeAuthor = "Taiizor";
            this.CB_Croshair_P2.ThemeName = "MetroLight";
            this.CB_Croshair_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel49
            // 
            this.nightHeaderLabel49.AutoSize = true;
            this.nightHeaderLabel49.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel49.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel49.Location = new System.Drawing.Point(288, 131);
            this.nightHeaderLabel49.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel49.Name = "nightHeaderLabel49";
            this.nightHeaderLabel49.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel49.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel49.Size = new System.Drawing.Size(133, 24);
            this.nightHeaderLabel49.TabIndex = 257;
            this.nightHeaderLabel49.Text = "ZM To Crosshair";
            this.nightHeaderLabel49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel49.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel49.UseCompatibleTextRendering = true;
            // 
            // CB_Rapid_P2
            // 
            this.CB_Rapid_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rapid_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rapid_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Rapid_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Rapid_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rapid_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rapid_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rapid_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P2.IsDerivedStyle = false;
            this.CB_Rapid_P2.Location = new System.Drawing.Point(10, 132);
            this.CB_Rapid_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rapid_P2.Name = "CB_Rapid_P2";
            this.CB_Rapid_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Rapid_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rapid_P2.StyleManager = null;
            this.CB_Rapid_P2.Switched = false;
            this.CB_Rapid_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rapid_P2.TabIndex = 256;
            this.CB_Rapid_P2.Text = "metroSwitch8";
            this.CB_Rapid_P2.ThemeAuthor = "Taiizor";
            this.CB_Rapid_P2.ThemeName = "MetroLight";
            this.CB_Rapid_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel50
            // 
            this.nightHeaderLabel50.AutoSize = true;
            this.nightHeaderLabel50.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel50.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel50.Location = new System.Drawing.Point(80, 131);
            this.nightHeaderLabel50.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel50.Name = "nightHeaderLabel50";
            this.nightHeaderLabel50.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel50.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel50.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel50.TabIndex = 255;
            this.nightHeaderLabel50.Text = "Rapid Fire";
            this.nightHeaderLabel50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel50.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel50.UseCompatibleTextRendering = true;
            // 
            // CB_Jail_P2
            // 
            this.CB_Jail_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Jail_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Jail_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Jail_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Jail_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Jail_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Jail_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Jail_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P2.IsDerivedStyle = false;
            this.CB_Jail_P2.Location = new System.Drawing.Point(218, 92);
            this.CB_Jail_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Jail_P2.Name = "CB_Jail_P2";
            this.CB_Jail_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Jail_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Jail_P2.StyleManager = null;
            this.CB_Jail_P2.Switched = false;
            this.CB_Jail_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Jail_P2.TabIndex = 254;
            this.CB_Jail_P2.Text = "metroSwitch5";
            this.CB_Jail_P2.ThemeAuthor = "Taiizor";
            this.CB_Jail_P2.ThemeName = "MetroLight";
            this.CB_Jail_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel51
            // 
            this.nightHeaderLabel51.AutoSize = true;
            this.nightHeaderLabel51.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel51.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel51.Location = new System.Drawing.Point(288, 91);
            this.nightHeaderLabel51.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel51.Name = "nightHeaderLabel51";
            this.nightHeaderLabel51.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel51.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel51.Size = new System.Drawing.Size(101, 24);
            this.nightHeaderLabel51.TabIndex = 253;
            this.nightHeaderLabel51.Text = "Send To Jail";
            this.nightHeaderLabel51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel51.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel51.UseCompatibleTextRendering = true;
            // 
            // CB_Crit_P2
            // 
            this.CB_Crit_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Crit_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Crit_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Crit_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Crit_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Crit_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Crit_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Crit_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P2.IsDerivedStyle = false;
            this.CB_Crit_P2.Location = new System.Drawing.Point(10, 92);
            this.CB_Crit_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Crit_P2.Name = "CB_Crit_P2";
            this.CB_Crit_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Crit_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Crit_P2.StyleManager = null;
            this.CB_Crit_P2.Switched = false;
            this.CB_Crit_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Crit_P2.TabIndex = 252;
            this.CB_Crit_P2.Text = "metroSwitch6";
            this.CB_Crit_P2.ThemeAuthor = "Taiizor";
            this.CB_Crit_P2.ThemeName = "MetroLight";
            this.CB_Crit_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel52
            // 
            this.nightHeaderLabel52.AutoSize = true;
            this.nightHeaderLabel52.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel52.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel52.Location = new System.Drawing.Point(80, 91);
            this.nightHeaderLabel52.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel52.Name = "nightHeaderLabel52";
            this.nightHeaderLabel52.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel52.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel52.Size = new System.Drawing.Size(116, 24);
            this.nightHeaderLabel52.TabIndex = 251;
            this.nightHeaderLabel52.Text = "100% Criticals";
            this.nightHeaderLabel52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel52.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel52.UseCompatibleTextRendering = true;
            // 
            // CB_Speed_P2
            // 
            this.CB_Speed_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Speed_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Speed_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Speed_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Speed_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Speed_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Speed_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Speed_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P2.IsDerivedStyle = false;
            this.CB_Speed_P2.Location = new System.Drawing.Point(218, 52);
            this.CB_Speed_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Speed_P2.Name = "CB_Speed_P2";
            this.CB_Speed_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Speed_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Speed_P2.StyleManager = null;
            this.CB_Speed_P2.Switched = false;
            this.CB_Speed_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Speed_P2.TabIndex = 250;
            this.CB_Speed_P2.Text = "metroSwitch3";
            this.CB_Speed_P2.ThemeAuthor = "Taiizor";
            this.CB_Speed_P2.ThemeName = "MetroLight";
            this.CB_Speed_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel53
            // 
            this.nightHeaderLabel53.AutoSize = true;
            this.nightHeaderLabel53.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel53.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel53.Location = new System.Drawing.Point(288, 51);
            this.nightHeaderLabel53.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel53.Name = "nightHeaderLabel53";
            this.nightHeaderLabel53.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel53.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel53.Size = new System.Drawing.Size(98, 24);
            this.nightHeaderLabel53.TabIndex = 249;
            this.nightHeaderLabel53.Text = "Speed Hack";
            this.nightHeaderLabel53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel53.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel53.UseCompatibleTextRendering = true;
            // 
            // CB_Ammo_P2
            // 
            this.CB_Ammo_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Ammo_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Ammo_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Ammo_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Ammo_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Ammo_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Ammo_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Ammo_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P2.IsDerivedStyle = false;
            this.CB_Ammo_P2.Location = new System.Drawing.Point(10, 52);
            this.CB_Ammo_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Ammo_P2.Name = "CB_Ammo_P2";
            this.CB_Ammo_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Ammo_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Ammo_P2.StyleManager = null;
            this.CB_Ammo_P2.Switched = false;
            this.CB_Ammo_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Ammo_P2.TabIndex = 248;
            this.CB_Ammo_P2.Text = "metroSwitch4";
            this.CB_Ammo_P2.ThemeAuthor = "Taiizor";
            this.CB_Ammo_P2.ThemeName = "MetroLight";
            this.CB_Ammo_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel54
            // 
            this.nightHeaderLabel54.AutoSize = true;
            this.nightHeaderLabel54.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel54.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel54.Location = new System.Drawing.Point(80, 51);
            this.nightHeaderLabel54.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel54.Name = "nightHeaderLabel54";
            this.nightHeaderLabel54.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel54.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel54.Size = new System.Drawing.Size(131, 24);
            this.nightHeaderLabel54.TabIndex = 247;
            this.nightHeaderLabel54.Text = "Unlimited Ammo";
            this.nightHeaderLabel54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel54.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel54.UseCompatibleTextRendering = true;
            // 
            // CB_Points_P2
            // 
            this.CB_Points_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_Points_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Points_P2.BorderColor = System.Drawing.Color.White;
            this.CB_Points_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_Points_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Points_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Points_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Points_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P2.IsDerivedStyle = false;
            this.CB_Points_P2.Location = new System.Drawing.Point(218, 12);
            this.CB_Points_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Points_P2.Name = "CB_Points_P2";
            this.CB_Points_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_Points_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Points_P2.StyleManager = null;
            this.CB_Points_P2.Switched = false;
            this.CB_Points_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Points_P2.TabIndex = 246;
            this.CB_Points_P2.Text = "metroSwitch2";
            this.CB_Points_P2.ThemeAuthor = "Taiizor";
            this.CB_Points_P2.ThemeName = "MetroLight";
            this.CB_Points_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel55
            // 
            this.nightHeaderLabel55.AutoSize = true;
            this.nightHeaderLabel55.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel55.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel55.Location = new System.Drawing.Point(288, 11);
            this.nightHeaderLabel55.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel55.Name = "nightHeaderLabel55";
            this.nightHeaderLabel55.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel55.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel55.Size = new System.Drawing.Size(130, 24);
            this.nightHeaderLabel55.TabIndex = 245;
            this.nightHeaderLabel55.Text = "Unlimited Points";
            this.nightHeaderLabel55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel55.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel55.UseCompatibleTextRendering = true;
            // 
            // CB_God_P2
            // 
            this.CB_God_P2.BackColor = System.Drawing.Color.Transparent;
            this.CB_God_P2.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_God_P2.BorderColor = System.Drawing.Color.White;
            this.CB_God_P2.CheckColor = System.Drawing.Color.Red;
            this.CB_God_P2.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_God_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_God_P2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P2.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_God_P2.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P2.IsDerivedStyle = false;
            this.CB_God_P2.Location = new System.Drawing.Point(10, 12);
            this.CB_God_P2.Margin = new System.Windows.Forms.Padding(9);
            this.CB_God_P2.Name = "CB_God_P2";
            this.CB_God_P2.Size = new System.Drawing.Size(58, 22);
            this.CB_God_P2.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_God_P2.StyleManager = null;
            this.CB_God_P2.Switched = false;
            this.CB_God_P2.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_God_P2.TabIndex = 244;
            this.CB_God_P2.Text = "metroSwitch1";
            this.CB_God_P2.ThemeAuthor = "Taiizor";
            this.CB_God_P2.ThemeName = "MetroLight";
            this.CB_God_P2.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel56
            // 
            this.nightHeaderLabel56.AutoSize = true;
            this.nightHeaderLabel56.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel56.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel56.Location = new System.Drawing.Point(80, 11);
            this.nightHeaderLabel56.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel56.Name = "nightHeaderLabel56";
            this.nightHeaderLabel56.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel56.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel56.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel56.TabIndex = 243;
            this.nightHeaderLabel56.Text = "God Mode";
            this.nightHeaderLabel56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel56.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel56.UseCompatibleTextRendering = true;
            // 
            // Panel_P3
            // 
            this.Panel_P3.BackColor = System.Drawing.Color.Transparent;
            this.Panel_P3.Controls.Add(this.nightHeaderLabel17);
            this.Panel_P3.Controls.Add(this.CB_zqinissofuckingsexy_P3);
            this.Panel_P3.Controls.Add(this.CB_Shoot_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel18);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel19);
            this.Panel_P3.Controls.Add(this.CB_Rainbow_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel20);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel21);
            this.Panel_P3.Controls.Add(this.Box_CycleEnd_P3);
            this.Panel_P3.Controls.Add(this.Box_CycleStart_P3);
            this.Panel_P3.Controls.Add(this.Btn_TP_P3);
            this.Panel_P3.Controls.Add(this.Btn_Gib2_P3);
            this.Panel_P3.Controls.Add(this.Btn_Gib_P3);
            this.Panel_P3.Controls.Add(this.Box_TP_P3);
            this.Panel_P3.Controls.Add(this.Box_Weapons_P3);
            this.Panel_P3.Controls.Add(this.CB_Cycle_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel22);
            this.Panel_P3.Controls.Add(this.CB_Croshair_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel23);
            this.Panel_P3.Controls.Add(this.CB_Rapid_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel24);
            this.Panel_P3.Controls.Add(this.CB_Jail_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel25);
            this.Panel_P3.Controls.Add(this.CB_Crit_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel26);
            this.Panel_P3.Controls.Add(this.CB_Speed_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel27);
            this.Panel_P3.Controls.Add(this.CB_Ammo_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel28);
            this.Panel_P3.Controls.Add(this.CB_Points_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel29);
            this.Panel_P3.Controls.Add(this.CB_God_P3);
            this.Panel_P3.Controls.Add(this.nightHeaderLabel30);
            this.Panel_P3.Location = new System.Drawing.Point(116, 129);
            this.Panel_P3.Name = "Panel_P3";
            this.Panel_P3.Size = new System.Drawing.Size(428, 500);
            this.Panel_P3.TabIndex = 175;
            // 
            // nightHeaderLabel17
            // 
            this.nightHeaderLabel17.AutoSize = true;
            this.nightHeaderLabel17.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel17.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel17.Location = new System.Drawing.Point(288, 212);
            this.nightHeaderLabel17.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel17.Name = "nightHeaderLabel17";
            this.nightHeaderLabel17.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel17.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel17.Size = new System.Drawing.Size(40, 24);
            this.nightHeaderLabel17.TabIndex = 275;
            this.nightHeaderLabel17.Text = "TBD";
            this.nightHeaderLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel17.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel17.UseCompatibleTextRendering = true;
            // 
            // CB_zqinissofuckingsexy_P3
            // 
            this.CB_zqinissofuckingsexy_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_zqinissofuckingsexy_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_zqinissofuckingsexy_P3.BorderColor = System.Drawing.Color.White;
            this.CB_zqinissofuckingsexy_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_zqinissofuckingsexy_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_zqinissofuckingsexy_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_zqinissofuckingsexy_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_zqinissofuckingsexy_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P3.IsDerivedStyle = false;
            this.CB_zqinissofuckingsexy_P3.Location = new System.Drawing.Point(218, 212);
            this.CB_zqinissofuckingsexy_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_zqinissofuckingsexy_P3.Name = "CB_zqinissofuckingsexy_P3";
            this.CB_zqinissofuckingsexy_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_zqinissofuckingsexy_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_zqinissofuckingsexy_P3.StyleManager = null;
            this.CB_zqinissofuckingsexy_P3.Switched = false;
            this.CB_zqinissofuckingsexy_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_zqinissofuckingsexy_P3.TabIndex = 274;
            this.CB_zqinissofuckingsexy_P3.Text = "metroSwitch7";
            this.CB_zqinissofuckingsexy_P3.ThemeAuthor = "Taiizor";
            this.CB_zqinissofuckingsexy_P3.ThemeName = "MetroLight";
            this.CB_zqinissofuckingsexy_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // CB_Shoot_P3
            // 
            this.CB_Shoot_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Shoot_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Shoot_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Shoot_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Shoot_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Shoot_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Shoot_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Shoot_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P3.IsDerivedStyle = false;
            this.CB_Shoot_P3.Location = new System.Drawing.Point(10, 212);
            this.CB_Shoot_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Shoot_P3.Name = "CB_Shoot_P3";
            this.CB_Shoot_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Shoot_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Shoot_P3.StyleManager = null;
            this.CB_Shoot_P3.Switched = false;
            this.CB_Shoot_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Shoot_P3.TabIndex = 273;
            this.CB_Shoot_P3.Text = "metroSwitch10";
            this.CB_Shoot_P3.ThemeAuthor = "Taiizor";
            this.CB_Shoot_P3.ThemeName = "MetroLight";
            this.CB_Shoot_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel18
            // 
            this.nightHeaderLabel18.AutoSize = true;
            this.nightHeaderLabel18.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel18.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel18.Location = new System.Drawing.Point(80, 211);
            this.nightHeaderLabel18.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel18.Name = "nightHeaderLabel18";
            this.nightHeaderLabel18.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel18.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel18.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel18.TabIndex = 272;
            this.nightHeaderLabel18.Text = "Auto Shoot";
            this.nightHeaderLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel18.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel18.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel19
            // 
            this.nightHeaderLabel19.AutoSize = true;
            this.nightHeaderLabel19.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel19.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel19.Location = new System.Drawing.Point(288, 172);
            this.nightHeaderLabel19.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel19.Name = "nightHeaderLabel19";
            this.nightHeaderLabel19.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel19.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel19.Size = new System.Drawing.Size(109, 24);
            this.nightHeaderLabel19.TabIndex = 271;
            this.nightHeaderLabel19.Text = "Rainbow Gun";
            this.nightHeaderLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel19.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel19.UseCompatibleTextRendering = true;
            // 
            // CB_Rainbow_P3
            // 
            this.CB_Rainbow_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rainbow_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rainbow_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Rainbow_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Rainbow_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rainbow_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rainbow_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rainbow_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P3.IsDerivedStyle = false;
            this.CB_Rainbow_P3.Location = new System.Drawing.Point(218, 172);
            this.CB_Rainbow_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rainbow_P3.Name = "CB_Rainbow_P3";
            this.CB_Rainbow_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Rainbow_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rainbow_P3.StyleManager = null;
            this.CB_Rainbow_P3.Switched = false;
            this.CB_Rainbow_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rainbow_P3.TabIndex = 270;
            this.CB_Rainbow_P3.Text = "metroSwitch7";
            this.CB_Rainbow_P3.ThemeAuthor = "Taiizor";
            this.CB_Rainbow_P3.ThemeName = "MetroLight";
            this.CB_Rainbow_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel20
            // 
            this.nightHeaderLabel20.AutoSize = true;
            this.nightHeaderLabel20.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel20.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel20.Location = new System.Drawing.Point(280, 276);
            this.nightHeaderLabel20.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel20.Name = "nightHeaderLabel20";
            this.nightHeaderLabel20.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel20.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel20.Size = new System.Drawing.Size(83, 24);
            this.nightHeaderLabel20.TabIndex = 269;
            this.nightHeaderLabel20.Text = "Cycle End";
            this.nightHeaderLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel20.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel20.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel21
            // 
            this.nightHeaderLabel21.AutoSize = true;
            this.nightHeaderLabel21.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel21.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel21.Location = new System.Drawing.Point(60, 279);
            this.nightHeaderLabel21.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel21.Name = "nightHeaderLabel21";
            this.nightHeaderLabel21.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel21.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel21.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel21.TabIndex = 268;
            this.nightHeaderLabel21.Text = "Cycle Start";
            this.nightHeaderLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel21.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel21.UseCompatibleTextRendering = true;
            // 
            // Box_CycleEnd_P3
            // 
            this.Box_CycleEnd_P3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleEnd_P3.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleEnd_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleEnd_P3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleEnd_P3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleEnd_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleEnd_P3.ForeColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P3.FormattingEnabled = true;
            this.Box_CycleEnd_P3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleEnd_P3.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P3.ItemHeight = 20;
            this.Box_CycleEnd_P3.Location = new System.Drawing.Point(226, 318);
            this.Box_CycleEnd_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleEnd_P3.Name = "Box_CycleEnd_P3";
            this.Box_CycleEnd_P3.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleEnd_P3.TabIndex = 267;
            // 
            // Box_CycleStart_P3
            // 
            this.Box_CycleStart_P3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleStart_P3.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleStart_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleStart_P3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleStart_P3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleStart_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleStart_P3.ForeColor = System.Drawing.Color.White;
            this.Box_CycleStart_P3.FormattingEnabled = true;
            this.Box_CycleStart_P3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleStart_P3.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleStart_P3.ItemHeight = 20;
            this.Box_CycleStart_P3.Location = new System.Drawing.Point(10, 318);
            this.Box_CycleStart_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleStart_P3.Name = "Box_CycleStart_P3";
            this.Box_CycleStart_P3.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleStart_P3.TabIndex = 266;
            // 
            // Btn_TP_P3
            // 
            this.Btn_TP_P3.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_TP_P3.BackgroundImage")));
            this.Btn_TP_P3.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_P3.Location = new System.Drawing.Point(10, 358);
            this.Btn_TP_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_P3.Name = "Btn_TP_P3";
            this.Btn_TP_P3.Rounded = false;
            this.Btn_TP_P3.Size = new System.Drawing.Size(406, 25);
            this.Btn_TP_P3.TabIndex = 265;
            this.Btn_TP_P3.Text = "Teleport To Location ↓";
            this.Btn_TP_P3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // Btn_Gib2_P3
            // 
            this.Btn_Gib2_P3.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib2_P3.BackgroundImage")));
            this.Btn_Gib2_P3.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib2_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib2_P3.Location = new System.Drawing.Point(224, 433);
            this.Btn_Gib2_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib2_P3.Name = "Btn_Gib2_P3";
            this.Btn_Gib2_P3.Rounded = false;
            this.Btn_Gib2_P3.Size = new System.Drawing.Size(192, 25);
            this.Btn_Gib2_P3.TabIndex = 264;
            this.Btn_Gib2_P3.Text = "Give Weapon 2 ↓";
            this.Btn_Gib2_P3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib2_P3.Click += new System.EventHandler(this.Btn_Gib2_P3_Click);
            // 
            // Btn_Gib_P3
            // 
            this.Btn_Gib_P3.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib_P3.BackgroundImage")));
            this.Btn_Gib_P3.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib_P3.Location = new System.Drawing.Point(10, 433);
            this.Btn_Gib_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib_P3.Name = "Btn_Gib_P3";
            this.Btn_Gib_P3.Rounded = false;
            this.Btn_Gib_P3.Size = new System.Drawing.Size(200, 25);
            this.Btn_Gib_P3.TabIndex = 263;
            this.Btn_Gib_P3.Text = "Give Weapon 1 ↓";
            this.Btn_Gib_P3.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib_P3.Click += new System.EventHandler(this.Btn_Gib_P3_Click);
            // 
            // Box_TP_P3
            // 
            this.Box_TP_P3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_TP_P3.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_TP_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_TP_P3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_TP_P3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_TP_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_TP_P3.ForeColor = System.Drawing.Color.White;
            this.Box_TP_P3.FormattingEnabled = true;
            this.Box_TP_P3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_TP_P3.HoverFontColor = System.Drawing.Color.White;
            this.Box_TP_P3.ItemHeight = 20;
            this.Box_TP_P3.Items.AddRange(new object[] {
            "Spawn",
            "Nacht",
            "Pond",
            "Power"});
            this.Box_TP_P3.Location = new System.Drawing.Point(10, 395);
            this.Box_TP_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Box_TP_P3.Name = "Box_TP_P3";
            this.Box_TP_P3.Size = new System.Drawing.Size(406, 26);
            this.Box_TP_P3.TabIndex = 262;
            // 
            // Box_Weapons_P3
            // 
            this.Box_Weapons_P3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_Weapons_P3.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_Weapons_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_Weapons_P3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_Weapons_P3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_Weapons_P3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_Weapons_P3.ForeColor = System.Drawing.Color.White;
            this.Box_Weapons_P3.FormattingEnabled = true;
            this.Box_Weapons_P3.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_Weapons_P3.HoverFontColor = System.Drawing.Color.White;
            this.Box_Weapons_P3.ItemHeight = 20;
            this.Box_Weapons_P3.Location = new System.Drawing.Point(10, 464);
            this.Box_Weapons_P3.Margin = new System.Windows.Forms.Padding(9);
            this.Box_Weapons_P3.Name = "Box_Weapons_P3";
            this.Box_Weapons_P3.Size = new System.Drawing.Size(406, 26);
            this.Box_Weapons_P3.TabIndex = 261;
            // 
            // CB_Cycle_P3
            // 
            this.CB_Cycle_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Cycle_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Cycle_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Cycle_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Cycle_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Cycle_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Cycle_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Cycle_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P3.IsDerivedStyle = false;
            this.CB_Cycle_P3.Location = new System.Drawing.Point(10, 172);
            this.CB_Cycle_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Cycle_P3.Name = "CB_Cycle_P3";
            this.CB_Cycle_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Cycle_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Cycle_P3.StyleManager = null;
            this.CB_Cycle_P3.Switched = false;
            this.CB_Cycle_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Cycle_P3.TabIndex = 260;
            this.CB_Cycle_P3.Text = "metroSwitch10";
            this.CB_Cycle_P3.ThemeAuthor = "Taiizor";
            this.CB_Cycle_P3.ThemeName = "MetroLight";
            this.CB_Cycle_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Cycle_P3.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_Cycle_P3_SwitchedChanged);
            // 
            // nightHeaderLabel22
            // 
            this.nightHeaderLabel22.AutoSize = true;
            this.nightHeaderLabel22.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel22.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel22.Location = new System.Drawing.Point(80, 171);
            this.nightHeaderLabel22.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel22.Name = "nightHeaderLabel22";
            this.nightHeaderLabel22.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel22.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel22.Size = new System.Drawing.Size(117, 24);
            this.nightHeaderLabel22.TabIndex = 259;
            this.nightHeaderLabel22.Text = "Weapon Cycle";
            this.nightHeaderLabel22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel22.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel22.UseCompatibleTextRendering = true;
            // 
            // CB_Croshair_P3
            // 
            this.CB_Croshair_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Croshair_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Croshair_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Croshair_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Croshair_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Croshair_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Croshair_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Croshair_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P3.IsDerivedStyle = false;
            this.CB_Croshair_P3.Location = new System.Drawing.Point(218, 132);
            this.CB_Croshair_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Croshair_P3.Name = "CB_Croshair_P3";
            this.CB_Croshair_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Croshair_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Croshair_P3.StyleManager = null;
            this.CB_Croshair_P3.Switched = false;
            this.CB_Croshair_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Croshair_P3.TabIndex = 258;
            this.CB_Croshair_P3.Text = "metroSwitch7";
            this.CB_Croshair_P3.ThemeAuthor = "Taiizor";
            this.CB_Croshair_P3.ThemeName = "MetroLight";
            this.CB_Croshair_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel23
            // 
            this.nightHeaderLabel23.AutoSize = true;
            this.nightHeaderLabel23.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel23.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel23.Location = new System.Drawing.Point(288, 131);
            this.nightHeaderLabel23.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel23.Name = "nightHeaderLabel23";
            this.nightHeaderLabel23.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel23.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel23.Size = new System.Drawing.Size(133, 24);
            this.nightHeaderLabel23.TabIndex = 257;
            this.nightHeaderLabel23.Text = "ZM To Crosshair";
            this.nightHeaderLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel23.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel23.UseCompatibleTextRendering = true;
            // 
            // CB_Rapid_P3
            // 
            this.CB_Rapid_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rapid_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rapid_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Rapid_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Rapid_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rapid_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rapid_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rapid_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P3.IsDerivedStyle = false;
            this.CB_Rapid_P3.Location = new System.Drawing.Point(10, 132);
            this.CB_Rapid_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rapid_P3.Name = "CB_Rapid_P3";
            this.CB_Rapid_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Rapid_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rapid_P3.StyleManager = null;
            this.CB_Rapid_P3.Switched = false;
            this.CB_Rapid_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rapid_P3.TabIndex = 256;
            this.CB_Rapid_P3.Text = "metroSwitch8";
            this.CB_Rapid_P3.ThemeAuthor = "Taiizor";
            this.CB_Rapid_P3.ThemeName = "MetroLight";
            this.CB_Rapid_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel24
            // 
            this.nightHeaderLabel24.AutoSize = true;
            this.nightHeaderLabel24.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel24.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel24.Location = new System.Drawing.Point(80, 131);
            this.nightHeaderLabel24.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel24.Name = "nightHeaderLabel24";
            this.nightHeaderLabel24.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel24.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel24.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel24.TabIndex = 255;
            this.nightHeaderLabel24.Text = "Rapid Fire";
            this.nightHeaderLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel24.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel24.UseCompatibleTextRendering = true;
            // 
            // CB_Jail_P3
            // 
            this.CB_Jail_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Jail_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Jail_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Jail_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Jail_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Jail_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Jail_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Jail_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P3.IsDerivedStyle = false;
            this.CB_Jail_P3.Location = new System.Drawing.Point(218, 92);
            this.CB_Jail_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Jail_P3.Name = "CB_Jail_P3";
            this.CB_Jail_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Jail_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Jail_P3.StyleManager = null;
            this.CB_Jail_P3.Switched = false;
            this.CB_Jail_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Jail_P3.TabIndex = 254;
            this.CB_Jail_P3.Text = "metroSwitch5";
            this.CB_Jail_P3.ThemeAuthor = "Taiizor";
            this.CB_Jail_P3.ThemeName = "MetroLight";
            this.CB_Jail_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel25
            // 
            this.nightHeaderLabel25.AutoSize = true;
            this.nightHeaderLabel25.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel25.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel25.Location = new System.Drawing.Point(288, 91);
            this.nightHeaderLabel25.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel25.Name = "nightHeaderLabel25";
            this.nightHeaderLabel25.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel25.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel25.Size = new System.Drawing.Size(101, 24);
            this.nightHeaderLabel25.TabIndex = 253;
            this.nightHeaderLabel25.Text = "Send To Jail";
            this.nightHeaderLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel25.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel25.UseCompatibleTextRendering = true;
            // 
            // CB_Crit_P3
            // 
            this.CB_Crit_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Crit_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Crit_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Crit_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Crit_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Crit_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Crit_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Crit_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P3.IsDerivedStyle = false;
            this.CB_Crit_P3.Location = new System.Drawing.Point(10, 92);
            this.CB_Crit_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Crit_P3.Name = "CB_Crit_P3";
            this.CB_Crit_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Crit_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Crit_P3.StyleManager = null;
            this.CB_Crit_P3.Switched = false;
            this.CB_Crit_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Crit_P3.TabIndex = 252;
            this.CB_Crit_P3.Text = "metroSwitch6";
            this.CB_Crit_P3.ThemeAuthor = "Taiizor";
            this.CB_Crit_P3.ThemeName = "MetroLight";
            this.CB_Crit_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel26
            // 
            this.nightHeaderLabel26.AutoSize = true;
            this.nightHeaderLabel26.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel26.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel26.Location = new System.Drawing.Point(80, 91);
            this.nightHeaderLabel26.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel26.Name = "nightHeaderLabel26";
            this.nightHeaderLabel26.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel26.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel26.Size = new System.Drawing.Size(116, 24);
            this.nightHeaderLabel26.TabIndex = 251;
            this.nightHeaderLabel26.Text = "100% Criticals";
            this.nightHeaderLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel26.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel26.UseCompatibleTextRendering = true;
            // 
            // CB_Speed_P3
            // 
            this.CB_Speed_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Speed_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Speed_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Speed_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Speed_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Speed_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Speed_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Speed_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P3.IsDerivedStyle = false;
            this.CB_Speed_P3.Location = new System.Drawing.Point(218, 52);
            this.CB_Speed_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Speed_P3.Name = "CB_Speed_P3";
            this.CB_Speed_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Speed_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Speed_P3.StyleManager = null;
            this.CB_Speed_P3.Switched = false;
            this.CB_Speed_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Speed_P3.TabIndex = 250;
            this.CB_Speed_P3.Text = "metroSwitch3";
            this.CB_Speed_P3.ThemeAuthor = "Taiizor";
            this.CB_Speed_P3.ThemeName = "MetroLight";
            this.CB_Speed_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel27
            // 
            this.nightHeaderLabel27.AutoSize = true;
            this.nightHeaderLabel27.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel27.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel27.Location = new System.Drawing.Point(288, 51);
            this.nightHeaderLabel27.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel27.Name = "nightHeaderLabel27";
            this.nightHeaderLabel27.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel27.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel27.Size = new System.Drawing.Size(98, 24);
            this.nightHeaderLabel27.TabIndex = 249;
            this.nightHeaderLabel27.Text = "Speed Hack";
            this.nightHeaderLabel27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel27.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel27.UseCompatibleTextRendering = true;
            // 
            // CB_Ammo_P3
            // 
            this.CB_Ammo_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Ammo_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Ammo_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Ammo_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Ammo_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Ammo_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Ammo_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Ammo_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P3.IsDerivedStyle = false;
            this.CB_Ammo_P3.Location = new System.Drawing.Point(10, 52);
            this.CB_Ammo_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Ammo_P3.Name = "CB_Ammo_P3";
            this.CB_Ammo_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Ammo_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Ammo_P3.StyleManager = null;
            this.CB_Ammo_P3.Switched = false;
            this.CB_Ammo_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Ammo_P3.TabIndex = 248;
            this.CB_Ammo_P3.Text = "metroSwitch4";
            this.CB_Ammo_P3.ThemeAuthor = "Taiizor";
            this.CB_Ammo_P3.ThemeName = "MetroLight";
            this.CB_Ammo_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel28
            // 
            this.nightHeaderLabel28.AutoSize = true;
            this.nightHeaderLabel28.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel28.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel28.Location = new System.Drawing.Point(80, 51);
            this.nightHeaderLabel28.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel28.Name = "nightHeaderLabel28";
            this.nightHeaderLabel28.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel28.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel28.Size = new System.Drawing.Size(131, 24);
            this.nightHeaderLabel28.TabIndex = 247;
            this.nightHeaderLabel28.Text = "Unlimited Ammo";
            this.nightHeaderLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel28.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel28.UseCompatibleTextRendering = true;
            // 
            // CB_Points_P3
            // 
            this.CB_Points_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_Points_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Points_P3.BorderColor = System.Drawing.Color.White;
            this.CB_Points_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_Points_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Points_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Points_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Points_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P3.IsDerivedStyle = false;
            this.CB_Points_P3.Location = new System.Drawing.Point(218, 12);
            this.CB_Points_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Points_P3.Name = "CB_Points_P3";
            this.CB_Points_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_Points_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Points_P3.StyleManager = null;
            this.CB_Points_P3.Switched = false;
            this.CB_Points_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Points_P3.TabIndex = 246;
            this.CB_Points_P3.Text = "metroSwitch2";
            this.CB_Points_P3.ThemeAuthor = "Taiizor";
            this.CB_Points_P3.ThemeName = "MetroLight";
            this.CB_Points_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel29
            // 
            this.nightHeaderLabel29.AutoSize = true;
            this.nightHeaderLabel29.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel29.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel29.Location = new System.Drawing.Point(288, 11);
            this.nightHeaderLabel29.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel29.Name = "nightHeaderLabel29";
            this.nightHeaderLabel29.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel29.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel29.Size = new System.Drawing.Size(130, 24);
            this.nightHeaderLabel29.TabIndex = 245;
            this.nightHeaderLabel29.Text = "Unlimited Points";
            this.nightHeaderLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel29.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel29.UseCompatibleTextRendering = true;
            // 
            // CB_God_P3
            // 
            this.CB_God_P3.BackColor = System.Drawing.Color.Transparent;
            this.CB_God_P3.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_God_P3.BorderColor = System.Drawing.Color.White;
            this.CB_God_P3.CheckColor = System.Drawing.Color.Red;
            this.CB_God_P3.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_God_P3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_God_P3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P3.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_God_P3.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P3.IsDerivedStyle = false;
            this.CB_God_P3.Location = new System.Drawing.Point(10, 12);
            this.CB_God_P3.Margin = new System.Windows.Forms.Padding(9);
            this.CB_God_P3.Name = "CB_God_P3";
            this.CB_God_P3.Size = new System.Drawing.Size(58, 22);
            this.CB_God_P3.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_God_P3.StyleManager = null;
            this.CB_God_P3.Switched = false;
            this.CB_God_P3.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_God_P3.TabIndex = 244;
            this.CB_God_P3.Text = "metroSwitch1";
            this.CB_God_P3.ThemeAuthor = "Taiizor";
            this.CB_God_P3.ThemeName = "MetroLight";
            this.CB_God_P3.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel30
            // 
            this.nightHeaderLabel30.AutoSize = true;
            this.nightHeaderLabel30.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel30.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel30.Location = new System.Drawing.Point(80, 11);
            this.nightHeaderLabel30.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel30.Name = "nightHeaderLabel30";
            this.nightHeaderLabel30.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel30.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel30.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel30.TabIndex = 243;
            this.nightHeaderLabel30.Text = "God Mode";
            this.nightHeaderLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel30.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel30.UseCompatibleTextRendering = true;
            // 
            // Panel_P4
            // 
            this.Panel_P4.BackColor = System.Drawing.Color.Transparent;
            this.Panel_P4.Controls.Add(this.nightHeaderLabel3);
            this.Panel_P4.Controls.Add(this.CB_zqinissofuckingsexy_P4);
            this.Panel_P4.Controls.Add(this.CB_Shoot_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel5);
            this.Panel_P4.Controls.Add(this.CB_Rainbow_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel6);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel7);
            this.Panel_P4.Controls.Add(this.Box_CycleEnd_P4);
            this.Panel_P4.Controls.Add(this.Box_CycleStart_P4);
            this.Panel_P4.Controls.Add(this.Btn_TP_P4);
            this.Panel_P4.Controls.Add(this.Btn_Gib2_P4);
            this.Panel_P4.Controls.Add(this.Btn_Gib_P4);
            this.Panel_P4.Controls.Add(this.Box_TP_P4);
            this.Panel_P4.Controls.Add(this.Box_Weapons_P4);
            this.Panel_P4.Controls.Add(this.CB_Cycle_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel8);
            this.Panel_P4.Controls.Add(this.CB_Croshair_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel9);
            this.Panel_P4.Controls.Add(this.CB_Rapid_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel10);
            this.Panel_P4.Controls.Add(this.CB_Jail_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel11);
            this.Panel_P4.Controls.Add(this.CB_Crit_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel12);
            this.Panel_P4.Controls.Add(this.CB_Speed_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel13);
            this.Panel_P4.Controls.Add(this.CB_Ammo_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel14);
            this.Panel_P4.Controls.Add(this.CB_Points_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel15);
            this.Panel_P4.Controls.Add(this.CB_God_P4);
            this.Panel_P4.Controls.Add(this.nightHeaderLabel16);
            this.Panel_P4.Location = new System.Drawing.Point(116, 129);
            this.Panel_P4.Name = "Panel_P4";
            this.Panel_P4.Size = new System.Drawing.Size(428, 500);
            this.Panel_P4.TabIndex = 176;
            // 
            // nightHeaderLabel3
            // 
            this.nightHeaderLabel3.AutoSize = true;
            this.nightHeaderLabel3.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel3.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel3.Location = new System.Drawing.Point(288, 212);
            this.nightHeaderLabel3.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel3.Name = "nightHeaderLabel3";
            this.nightHeaderLabel3.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel3.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel3.Size = new System.Drawing.Size(40, 24);
            this.nightHeaderLabel3.TabIndex = 275;
            this.nightHeaderLabel3.Text = "TBD";
            this.nightHeaderLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel3.UseCompatibleTextRendering = true;
            // 
            // CB_zqinissofuckingsexy_P4
            // 
            this.CB_zqinissofuckingsexy_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_zqinissofuckingsexy_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_zqinissofuckingsexy_P4.BorderColor = System.Drawing.Color.White;
            this.CB_zqinissofuckingsexy_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_zqinissofuckingsexy_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_zqinissofuckingsexy_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_zqinissofuckingsexy_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_zqinissofuckingsexy_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_zqinissofuckingsexy_P4.IsDerivedStyle = false;
            this.CB_zqinissofuckingsexy_P4.Location = new System.Drawing.Point(218, 212);
            this.CB_zqinissofuckingsexy_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_zqinissofuckingsexy_P4.Name = "CB_zqinissofuckingsexy_P4";
            this.CB_zqinissofuckingsexy_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_zqinissofuckingsexy_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_zqinissofuckingsexy_P4.StyleManager = null;
            this.CB_zqinissofuckingsexy_P4.Switched = false;
            this.CB_zqinissofuckingsexy_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_zqinissofuckingsexy_P4.TabIndex = 274;
            this.CB_zqinissofuckingsexy_P4.Text = "metroSwitch7";
            this.CB_zqinissofuckingsexy_P4.ThemeAuthor = "Taiizor";
            this.CB_zqinissofuckingsexy_P4.ThemeName = "MetroLight";
            this.CB_zqinissofuckingsexy_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // CB_Shoot_P4
            // 
            this.CB_Shoot_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Shoot_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Shoot_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Shoot_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Shoot_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Shoot_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Shoot_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Shoot_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Shoot_P4.IsDerivedStyle = false;
            this.CB_Shoot_P4.Location = new System.Drawing.Point(10, 212);
            this.CB_Shoot_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Shoot_P4.Name = "CB_Shoot_P4";
            this.CB_Shoot_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Shoot_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Shoot_P4.StyleManager = null;
            this.CB_Shoot_P4.Switched = false;
            this.CB_Shoot_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Shoot_P4.TabIndex = 273;
            this.CB_Shoot_P4.Text = "metroSwitch10";
            this.CB_Shoot_P4.ThemeAuthor = "Taiizor";
            this.CB_Shoot_P4.ThemeName = "MetroLight";
            this.CB_Shoot_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel4
            // 
            this.nightHeaderLabel4.AutoSize = true;
            this.nightHeaderLabel4.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel4.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel4.Location = new System.Drawing.Point(80, 211);
            this.nightHeaderLabel4.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel4.Name = "nightHeaderLabel4";
            this.nightHeaderLabel4.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel4.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel4.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel4.TabIndex = 272;
            this.nightHeaderLabel4.Text = "Auto Shoot";
            this.nightHeaderLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel4.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel5
            // 
            this.nightHeaderLabel5.AutoSize = true;
            this.nightHeaderLabel5.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel5.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel5.Location = new System.Drawing.Point(288, 172);
            this.nightHeaderLabel5.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel5.Name = "nightHeaderLabel5";
            this.nightHeaderLabel5.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel5.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel5.Size = new System.Drawing.Size(109, 24);
            this.nightHeaderLabel5.TabIndex = 271;
            this.nightHeaderLabel5.Text = "Rainbow Gun";
            this.nightHeaderLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel5.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel5.UseCompatibleTextRendering = true;
            // 
            // CB_Rainbow_P4
            // 
            this.CB_Rainbow_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rainbow_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rainbow_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Rainbow_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Rainbow_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rainbow_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rainbow_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rainbow_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rainbow_P4.IsDerivedStyle = false;
            this.CB_Rainbow_P4.Location = new System.Drawing.Point(218, 172);
            this.CB_Rainbow_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rainbow_P4.Name = "CB_Rainbow_P4";
            this.CB_Rainbow_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Rainbow_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rainbow_P4.StyleManager = null;
            this.CB_Rainbow_P4.Switched = false;
            this.CB_Rainbow_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rainbow_P4.TabIndex = 270;
            this.CB_Rainbow_P4.Text = "metroSwitch7";
            this.CB_Rainbow_P4.ThemeAuthor = "Taiizor";
            this.CB_Rainbow_P4.ThemeName = "MetroLight";
            this.CB_Rainbow_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel6
            // 
            this.nightHeaderLabel6.AutoSize = true;
            this.nightHeaderLabel6.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel6.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel6.Location = new System.Drawing.Point(280, 276);
            this.nightHeaderLabel6.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel6.Name = "nightHeaderLabel6";
            this.nightHeaderLabel6.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel6.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel6.Size = new System.Drawing.Size(83, 24);
            this.nightHeaderLabel6.TabIndex = 269;
            this.nightHeaderLabel6.Text = "Cycle End";
            this.nightHeaderLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel6.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel6.UseCompatibleTextRendering = true;
            // 
            // nightHeaderLabel7
            // 
            this.nightHeaderLabel7.AutoSize = true;
            this.nightHeaderLabel7.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel7.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel7.Location = new System.Drawing.Point(60, 279);
            this.nightHeaderLabel7.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel7.Name = "nightHeaderLabel7";
            this.nightHeaderLabel7.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel7.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel7.Size = new System.Drawing.Size(90, 24);
            this.nightHeaderLabel7.TabIndex = 268;
            this.nightHeaderLabel7.Text = "Cycle Start";
            this.nightHeaderLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel7.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel7.UseCompatibleTextRendering = true;
            // 
            // Box_CycleEnd_P4
            // 
            this.Box_CycleEnd_P4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleEnd_P4.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleEnd_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleEnd_P4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleEnd_P4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleEnd_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleEnd_P4.ForeColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P4.FormattingEnabled = true;
            this.Box_CycleEnd_P4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleEnd_P4.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleEnd_P4.ItemHeight = 20;
            this.Box_CycleEnd_P4.Location = new System.Drawing.Point(226, 318);
            this.Box_CycleEnd_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleEnd_P4.Name = "Box_CycleEnd_P4";
            this.Box_CycleEnd_P4.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleEnd_P4.TabIndex = 267;
            // 
            // Box_CycleStart_P4
            // 
            this.Box_CycleStart_P4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_CycleStart_P4.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_CycleStart_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_CycleStart_P4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_CycleStart_P4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_CycleStart_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_CycleStart_P4.ForeColor = System.Drawing.Color.White;
            this.Box_CycleStart_P4.FormattingEnabled = true;
            this.Box_CycleStart_P4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_CycleStart_P4.HoverFontColor = System.Drawing.Color.White;
            this.Box_CycleStart_P4.ItemHeight = 20;
            this.Box_CycleStart_P4.Location = new System.Drawing.Point(10, 318);
            this.Box_CycleStart_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Box_CycleStart_P4.Name = "Box_CycleStart_P4";
            this.Box_CycleStart_P4.Size = new System.Drawing.Size(190, 26);
            this.Box_CycleStart_P4.TabIndex = 266;
            // 
            // Btn_TP_P4
            // 
            this.Btn_TP_P4.BackColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_TP_P4.BackgroundImage")));
            this.Btn_TP_P4.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_TP_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_TP_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_TP_P4.Location = new System.Drawing.Point(10, 358);
            this.Btn_TP_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_TP_P4.Name = "Btn_TP_P4";
            this.Btn_TP_P4.Rounded = false;
            this.Btn_TP_P4.Size = new System.Drawing.Size(406, 25);
            this.Btn_TP_P4.TabIndex = 265;
            this.Btn_TP_P4.Text = "Teleport To Location ↓";
            this.Btn_TP_P4.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // Btn_Gib2_P4
            // 
            this.Btn_Gib2_P4.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib2_P4.BackgroundImage")));
            this.Btn_Gib2_P4.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib2_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib2_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib2_P4.Location = new System.Drawing.Point(224, 433);
            this.Btn_Gib2_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib2_P4.Name = "Btn_Gib2_P4";
            this.Btn_Gib2_P4.Rounded = false;
            this.Btn_Gib2_P4.Size = new System.Drawing.Size(192, 25);
            this.Btn_Gib2_P4.TabIndex = 264;
            this.Btn_Gib2_P4.Text = "Give Weapon 2 ↓";
            this.Btn_Gib2_P4.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib2_P4.Click += new System.EventHandler(this.Btn_Gib2_P4_Click);
            // 
            // Btn_Gib_P4
            // 
            this.Btn_Gib_P4.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_Gib_P4.BackgroundImage")));
            this.Btn_Gib_P4.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Gib_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Gib_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Gib_P4.Location = new System.Drawing.Point(10, 433);
            this.Btn_Gib_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Btn_Gib_P4.Name = "Btn_Gib_P4";
            this.Btn_Gib_P4.Rounded = false;
            this.Btn_Gib_P4.Size = new System.Drawing.Size(200, 25);
            this.Btn_Gib_P4.TabIndex = 263;
            this.Btn_Gib_P4.Text = "Give Weapon 1 ↓";
            this.Btn_Gib_P4.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Btn_Gib_P4.Click += new System.EventHandler(this.Btn_Gib_P4_Click);
            // 
            // Box_TP_P4
            // 
            this.Box_TP_P4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_TP_P4.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_TP_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_TP_P4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_TP_P4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_TP_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_TP_P4.ForeColor = System.Drawing.Color.White;
            this.Box_TP_P4.FormattingEnabled = true;
            this.Box_TP_P4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_TP_P4.HoverFontColor = System.Drawing.Color.White;
            this.Box_TP_P4.ItemHeight = 20;
            this.Box_TP_P4.Items.AddRange(new object[] {
            "Spawn",
            "Nacht",
            "Pond",
            "Power"});
            this.Box_TP_P4.Location = new System.Drawing.Point(10, 395);
            this.Box_TP_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Box_TP_P4.Name = "Box_TP_P4";
            this.Box_TP_P4.Size = new System.Drawing.Size(406, 26);
            this.Box_TP_P4.TabIndex = 262;
            // 
            // Box_Weapons_P4
            // 
            this.Box_Weapons_P4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(27)))), ((int)(((byte)(29)))));
            this.Box_Weapons_P4.BGColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.Box_Weapons_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Box_Weapons_P4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Box_Weapons_P4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_Weapons_P4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Box_Weapons_P4.ForeColor = System.Drawing.Color.White;
            this.Box_Weapons_P4.FormattingEnabled = true;
            this.Box_Weapons_P4.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(49)))), ((int)(((byte)(222)))));
            this.Box_Weapons_P4.HoverFontColor = System.Drawing.Color.White;
            this.Box_Weapons_P4.ItemHeight = 20;
            this.Box_Weapons_P4.Location = new System.Drawing.Point(10, 464);
            this.Box_Weapons_P4.Margin = new System.Windows.Forms.Padding(9);
            this.Box_Weapons_P4.Name = "Box_Weapons_P4";
            this.Box_Weapons_P4.Size = new System.Drawing.Size(406, 26);
            this.Box_Weapons_P4.TabIndex = 261;
            // 
            // CB_Cycle_P4
            // 
            this.CB_Cycle_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Cycle_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Cycle_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Cycle_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Cycle_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Cycle_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Cycle_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Cycle_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Cycle_P4.IsDerivedStyle = false;
            this.CB_Cycle_P4.Location = new System.Drawing.Point(10, 172);
            this.CB_Cycle_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Cycle_P4.Name = "CB_Cycle_P4";
            this.CB_Cycle_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Cycle_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Cycle_P4.StyleManager = null;
            this.CB_Cycle_P4.Switched = false;
            this.CB_Cycle_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Cycle_P4.TabIndex = 260;
            this.CB_Cycle_P4.Text = "metroSwitch10";
            this.CB_Cycle_P4.ThemeAuthor = "Taiizor";
            this.CB_Cycle_P4.ThemeName = "MetroLight";
            this.CB_Cycle_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_Cycle_P4.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_Cycle_P4_SwitchedChanged);
            // 
            // nightHeaderLabel8
            // 
            this.nightHeaderLabel8.AutoSize = true;
            this.nightHeaderLabel8.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel8.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel8.Location = new System.Drawing.Point(80, 171);
            this.nightHeaderLabel8.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel8.Name = "nightHeaderLabel8";
            this.nightHeaderLabel8.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel8.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel8.Size = new System.Drawing.Size(117, 24);
            this.nightHeaderLabel8.TabIndex = 259;
            this.nightHeaderLabel8.Text = "Weapon Cycle";
            this.nightHeaderLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel8.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel8.UseCompatibleTextRendering = true;
            // 
            // CB_Croshair_P4
            // 
            this.CB_Croshair_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Croshair_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Croshair_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Croshair_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Croshair_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Croshair_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Croshair_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Croshair_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Croshair_P4.IsDerivedStyle = false;
            this.CB_Croshair_P4.Location = new System.Drawing.Point(218, 132);
            this.CB_Croshair_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Croshair_P4.Name = "CB_Croshair_P4";
            this.CB_Croshair_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Croshair_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Croshair_P4.StyleManager = null;
            this.CB_Croshair_P4.Switched = false;
            this.CB_Croshair_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Croshair_P4.TabIndex = 258;
            this.CB_Croshair_P4.Text = "metroSwitch7";
            this.CB_Croshair_P4.ThemeAuthor = "Taiizor";
            this.CB_Croshair_P4.ThemeName = "MetroLight";
            this.CB_Croshair_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel9
            // 
            this.nightHeaderLabel9.AutoSize = true;
            this.nightHeaderLabel9.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel9.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel9.Location = new System.Drawing.Point(288, 131);
            this.nightHeaderLabel9.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel9.Name = "nightHeaderLabel9";
            this.nightHeaderLabel9.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel9.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel9.Size = new System.Drawing.Size(133, 24);
            this.nightHeaderLabel9.TabIndex = 257;
            this.nightHeaderLabel9.Text = "ZM To Crosshair";
            this.nightHeaderLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel9.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel9.UseCompatibleTextRendering = true;
            // 
            // CB_Rapid_P4
            // 
            this.CB_Rapid_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Rapid_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Rapid_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Rapid_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Rapid_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Rapid_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Rapid_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Rapid_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Rapid_P4.IsDerivedStyle = false;
            this.CB_Rapid_P4.Location = new System.Drawing.Point(10, 132);
            this.CB_Rapid_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Rapid_P4.Name = "CB_Rapid_P4";
            this.CB_Rapid_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Rapid_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Rapid_P4.StyleManager = null;
            this.CB_Rapid_P4.Switched = false;
            this.CB_Rapid_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Rapid_P4.TabIndex = 256;
            this.CB_Rapid_P4.Text = "metroSwitch8";
            this.CB_Rapid_P4.ThemeAuthor = "Taiizor";
            this.CB_Rapid_P4.ThemeName = "MetroLight";
            this.CB_Rapid_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel10
            // 
            this.nightHeaderLabel10.AutoSize = true;
            this.nightHeaderLabel10.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel10.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel10.Location = new System.Drawing.Point(80, 131);
            this.nightHeaderLabel10.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel10.Name = "nightHeaderLabel10";
            this.nightHeaderLabel10.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel10.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel10.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel10.TabIndex = 255;
            this.nightHeaderLabel10.Text = "Rapid Fire";
            this.nightHeaderLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel10.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel10.UseCompatibleTextRendering = true;
            // 
            // CB_Jail_P4
            // 
            this.CB_Jail_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Jail_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Jail_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Jail_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Jail_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Jail_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Jail_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Jail_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Jail_P4.IsDerivedStyle = false;
            this.CB_Jail_P4.Location = new System.Drawing.Point(218, 92);
            this.CB_Jail_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Jail_P4.Name = "CB_Jail_P4";
            this.CB_Jail_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Jail_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Jail_P4.StyleManager = null;
            this.CB_Jail_P4.Switched = false;
            this.CB_Jail_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Jail_P4.TabIndex = 254;
            this.CB_Jail_P4.Text = "metroSwitch5";
            this.CB_Jail_P4.ThemeAuthor = "Taiizor";
            this.CB_Jail_P4.ThemeName = "MetroLight";
            this.CB_Jail_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel11
            // 
            this.nightHeaderLabel11.AutoSize = true;
            this.nightHeaderLabel11.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel11.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel11.Location = new System.Drawing.Point(288, 91);
            this.nightHeaderLabel11.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel11.Name = "nightHeaderLabel11";
            this.nightHeaderLabel11.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel11.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel11.Size = new System.Drawing.Size(101, 24);
            this.nightHeaderLabel11.TabIndex = 253;
            this.nightHeaderLabel11.Text = "Send To Jail";
            this.nightHeaderLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel11.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel11.UseCompatibleTextRendering = true;
            // 
            // CB_Crit_P4
            // 
            this.CB_Crit_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Crit_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Crit_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Crit_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Crit_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Crit_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Crit_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Crit_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Crit_P4.IsDerivedStyle = false;
            this.CB_Crit_P4.Location = new System.Drawing.Point(10, 92);
            this.CB_Crit_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Crit_P4.Name = "CB_Crit_P4";
            this.CB_Crit_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Crit_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Crit_P4.StyleManager = null;
            this.CB_Crit_P4.Switched = false;
            this.CB_Crit_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Crit_P4.TabIndex = 252;
            this.CB_Crit_P4.Text = "metroSwitch6";
            this.CB_Crit_P4.ThemeAuthor = "Taiizor";
            this.CB_Crit_P4.ThemeName = "MetroLight";
            this.CB_Crit_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel12
            // 
            this.nightHeaderLabel12.AutoSize = true;
            this.nightHeaderLabel12.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel12.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel12.Location = new System.Drawing.Point(80, 91);
            this.nightHeaderLabel12.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel12.Name = "nightHeaderLabel12";
            this.nightHeaderLabel12.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel12.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel12.Size = new System.Drawing.Size(116, 24);
            this.nightHeaderLabel12.TabIndex = 251;
            this.nightHeaderLabel12.Text = "100% Criticals";
            this.nightHeaderLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel12.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel12.UseCompatibleTextRendering = true;
            // 
            // CB_Speed_P4
            // 
            this.CB_Speed_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Speed_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Speed_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Speed_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Speed_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Speed_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Speed_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Speed_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Speed_P4.IsDerivedStyle = false;
            this.CB_Speed_P4.Location = new System.Drawing.Point(218, 52);
            this.CB_Speed_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Speed_P4.Name = "CB_Speed_P4";
            this.CB_Speed_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Speed_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Speed_P4.StyleManager = null;
            this.CB_Speed_P4.Switched = false;
            this.CB_Speed_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Speed_P4.TabIndex = 250;
            this.CB_Speed_P4.Text = "metroSwitch3";
            this.CB_Speed_P4.ThemeAuthor = "Taiizor";
            this.CB_Speed_P4.ThemeName = "MetroLight";
            this.CB_Speed_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel13
            // 
            this.nightHeaderLabel13.AutoSize = true;
            this.nightHeaderLabel13.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel13.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel13.Location = new System.Drawing.Point(288, 51);
            this.nightHeaderLabel13.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel13.Name = "nightHeaderLabel13";
            this.nightHeaderLabel13.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel13.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel13.Size = new System.Drawing.Size(98, 24);
            this.nightHeaderLabel13.TabIndex = 249;
            this.nightHeaderLabel13.Text = "Speed Hack";
            this.nightHeaderLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel13.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel13.UseCompatibleTextRendering = true;
            // 
            // CB_Ammo_P4
            // 
            this.CB_Ammo_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Ammo_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Ammo_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Ammo_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Ammo_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Ammo_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Ammo_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Ammo_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Ammo_P4.IsDerivedStyle = false;
            this.CB_Ammo_P4.Location = new System.Drawing.Point(10, 52);
            this.CB_Ammo_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Ammo_P4.Name = "CB_Ammo_P4";
            this.CB_Ammo_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Ammo_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Ammo_P4.StyleManager = null;
            this.CB_Ammo_P4.Switched = false;
            this.CB_Ammo_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Ammo_P4.TabIndex = 248;
            this.CB_Ammo_P4.Text = "metroSwitch4";
            this.CB_Ammo_P4.ThemeAuthor = "Taiizor";
            this.CB_Ammo_P4.ThemeName = "MetroLight";
            this.CB_Ammo_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel14
            // 
            this.nightHeaderLabel14.AutoSize = true;
            this.nightHeaderLabel14.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel14.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel14.Location = new System.Drawing.Point(80, 51);
            this.nightHeaderLabel14.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel14.Name = "nightHeaderLabel14";
            this.nightHeaderLabel14.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel14.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel14.Size = new System.Drawing.Size(131, 24);
            this.nightHeaderLabel14.TabIndex = 247;
            this.nightHeaderLabel14.Text = "Unlimited Ammo";
            this.nightHeaderLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel14.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel14.UseCompatibleTextRendering = true;
            // 
            // CB_Points_P4
            // 
            this.CB_Points_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_Points_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_Points_P4.BorderColor = System.Drawing.Color.White;
            this.CB_Points_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_Points_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_Points_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Points_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_Points_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_Points_P4.IsDerivedStyle = false;
            this.CB_Points_P4.Location = new System.Drawing.Point(218, 12);
            this.CB_Points_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_Points_P4.Name = "CB_Points_P4";
            this.CB_Points_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_Points_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_Points_P4.StyleManager = null;
            this.CB_Points_P4.Switched = false;
            this.CB_Points_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_Points_P4.TabIndex = 246;
            this.CB_Points_P4.Text = "metroSwitch2";
            this.CB_Points_P4.ThemeAuthor = "Taiizor";
            this.CB_Points_P4.ThemeName = "MetroLight";
            this.CB_Points_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel15
            // 
            this.nightHeaderLabel15.AutoSize = true;
            this.nightHeaderLabel15.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel15.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel15.Location = new System.Drawing.Point(288, 11);
            this.nightHeaderLabel15.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel15.Name = "nightHeaderLabel15";
            this.nightHeaderLabel15.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel15.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel15.Size = new System.Drawing.Size(130, 24);
            this.nightHeaderLabel15.TabIndex = 245;
            this.nightHeaderLabel15.Text = "Unlimited Points";
            this.nightHeaderLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel15.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel15.UseCompatibleTextRendering = true;
            // 
            // CB_God_P4
            // 
            this.CB_God_P4.BackColor = System.Drawing.Color.Transparent;
            this.CB_God_P4.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_God_P4.BorderColor = System.Drawing.Color.White;
            this.CB_God_P4.CheckColor = System.Drawing.Color.Red;
            this.CB_God_P4.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_God_P4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_God_P4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P4.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_God_P4.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_God_P4.IsDerivedStyle = false;
            this.CB_God_P4.Location = new System.Drawing.Point(10, 12);
            this.CB_God_P4.Margin = new System.Windows.Forms.Padding(9);
            this.CB_God_P4.Name = "CB_God_P4";
            this.CB_God_P4.Size = new System.Drawing.Size(58, 22);
            this.CB_God_P4.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_God_P4.StyleManager = null;
            this.CB_God_P4.Switched = false;
            this.CB_God_P4.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_God_P4.TabIndex = 244;
            this.CB_God_P4.Text = "metroSwitch1";
            this.CB_God_P4.ThemeAuthor = "Taiizor";
            this.CB_God_P4.ThemeName = "MetroLight";
            this.CB_God_P4.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            // 
            // nightHeaderLabel16
            // 
            this.nightHeaderLabel16.AutoSize = true;
            this.nightHeaderLabel16.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel16.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel16.Location = new System.Drawing.Point(80, 11);
            this.nightHeaderLabel16.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel16.Name = "nightHeaderLabel16";
            this.nightHeaderLabel16.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel16.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel16.Size = new System.Drawing.Size(85, 24);
            this.nightHeaderLabel16.TabIndex = 243;
            this.nightHeaderLabel16.Text = "God Mode";
            this.nightHeaderLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel16.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel16.UseCompatibleTextRendering = true;
            // 
            // LBL_PlayerName
            // 
            this.LBL_PlayerName.AutoSize = true;
            this.LBL_PlayerName.BackColor = System.Drawing.Color.Transparent;
            this.LBL_PlayerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_PlayerName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_PlayerName.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_PlayerName.Location = new System.Drawing.Point(116, 96);
            this.LBL_PlayerName.Margin = new System.Windows.Forms.Padding(9);
            this.LBL_PlayerName.Name = "LBL_PlayerName";
            this.LBL_PlayerName.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.LBL_PlayerName.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.LBL_PlayerName.Size = new System.Drawing.Size(106, 24);
            this.LBL_PlayerName.TabIndex = 211;
            this.LBL_PlayerName.Text = "Player Name:";
            this.LBL_PlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBL_PlayerName.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.LBL_PlayerName.UseCompatibleTextRendering = true;
            this.LBL_PlayerName.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 10;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // LBL_Gun
            // 
            this.LBL_Gun.AutoSize = true;
            this.LBL_Gun.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Gun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Gun.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Gun.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.LBL_Gun.Location = new System.Drawing.Point(18, 658);
            this.LBL_Gun.Margin = new System.Windows.Forms.Padding(9);
            this.LBL_Gun.Name = "LBL_Gun";
            this.LBL_Gun.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.LBL_Gun.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.LBL_Gun.Size = new System.Drawing.Size(135, 24);
            this.LBL_Gun.TabIndex = 212;
            this.LBL_Gun.Text = "Current Gun ID: 0";
            this.LBL_Gun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LBL_Gun.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.LBL_Gun.UseCompatibleTextRendering = true;
            this.LBL_Gun.Click += new System.EventHandler(this.LBL_Gun_Click);
            // 
            // XP_Timer
            // 
            this.XP_Timer.Interval = 1;
            this.XP_Timer.Tick += new System.EventHandler(this.XP_Timer_Tick);
            // 
            // CB_XP
            // 
            this.CB_XP.BackColor = System.Drawing.Color.Transparent;
            this.CB_XP.BackgroundColor = System.Drawing.Color.Empty;
            this.CB_XP.BorderColor = System.Drawing.Color.White;
            this.CB_XP.CheckColor = System.Drawing.Color.Red;
            this.CB_XP.CheckState = ReaLTaiizor.Enum.Metro.CheckState.Unchecked;
            this.CB_XP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_XP.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_XP.DisabledCheckColor = System.Drawing.Color.Maroon;
            this.CB_XP.DisabledUnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.CB_XP.IsDerivedStyle = false;
            this.CB_XP.Location = new System.Drawing.Point(238, 328);
            this.CB_XP.Margin = new System.Windows.Forms.Padding(9);
            this.CB_XP.Name = "CB_XP";
            this.CB_XP.Size = new System.Drawing.Size(58, 22);
            this.CB_XP.Style = ReaLTaiizor.Enum.Metro.Style.Custom;
            this.CB_XP.StyleManager = null;
            this.CB_XP.Switched = false;
            this.CB_XP.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.CB_XP.TabIndex = 276;
            this.CB_XP.Text = "metroSwitch1";
            this.CB_XP.ThemeAuthor = "Taiizor";
            this.CB_XP.ThemeName = "MetroLight";
            this.CB_XP.UnCheckColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(155)))));
            this.CB_XP.SwitchedChanged += new ReaLTaiizor.Controls.MetroSwitch.SwitchedChangedEventHandler(this.CB_XP_SwitchedChanged_1);
            // 
            // nightHeaderLabel62
            // 
            this.nightHeaderLabel62.AutoSize = true;
            this.nightHeaderLabel62.BackColor = System.Drawing.Color.Transparent;
            this.nightHeaderLabel62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nightHeaderLabel62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel62.LeftSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.nightHeaderLabel62.Location = new System.Drawing.Point(308, 327);
            this.nightHeaderLabel62.Margin = new System.Windows.Forms.Padding(9);
            this.nightHeaderLabel62.Name = "nightHeaderLabel62";
            this.nightHeaderLabel62.RightSideForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.nightHeaderLabel62.Side = ReaLTaiizor.Controls.NightHeaderLabel.PanelSide.LeftPanel;
            this.nightHeaderLabel62.Size = new System.Drawing.Size(76, 24);
            this.nightHeaderLabel62.TabIndex = 277;
            this.nightHeaderLabel62.Text = "XP Cycle";
            this.nightHeaderLabel62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.nightHeaderLabel62.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.nightHeaderLabel62.UseCompatibleTextRendering = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PornHub.Properties.Resources.UI2_0_1;
            this.ClientSize = new System.Drawing.Size(560, 700);
            this.Controls.Add(this.LBL_Gun);
            this.Controls.Add(this.LBL_PlayerName);
            this.Controls.Add(this.Form_Header);
            this.Controls.Add(this.Panel_LeftSide);
            this.Controls.Add(this.Panel_Server);
            this.Controls.Add(this.Panel_P4);
            this.Controls.Add(this.Panel_P3);
            this.Controls.Add(this.Panel_P2);
            this.Controls.Add(this.Panel_P1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Panel_LeftSide.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Btn_Discord_Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P4_Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P3_Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P2_Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_P1_Icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Btn_Server_Icon)).EndInit();
            this.Panel_Server.ResumeLayout(false);
            this.Panel_Server.PerformLayout();
            this.Form_Header.ResumeLayout(false);
            this.Panel_P1.ResumeLayout(false);
            this.Panel_P1.PerformLayout();
            this.Panel_P2.ResumeLayout(false);
            this.Panel_P2.PerformLayout();
            this.Panel_P3.ResumeLayout(false);
            this.Panel_P3.PerformLayout();
            this.Panel_P4.ResumeLayout(false);
            this.Panel_P4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Panel Panel_LeftSide;
        public System.Windows.Forms.Timer Animations;
        public FontAwesome.Sharp.IconPictureBox Btn_Server_Icon;
        public FontAwesome.Sharp.IconPictureBox Btn_Discord_Icon;
        public FontAwesome.Sharp.IconPictureBox Btn_P4_Icon;
        public System.Windows.Forms.Panel panel5;
        public FontAwesome.Sharp.IconPictureBox Btn_P3_Icon;
        public System.Windows.Forms.Panel panel4;
        public FontAwesome.Sharp.IconPictureBox Btn_P2_Icon;
        public System.Windows.Forms.Panel panel3;
        public FontAwesome.Sharp.IconPictureBox Btn_P1_Icon;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Panel Btn_Server_BG;
        public System.Windows.Forms.Panel Panel_Server;
        public ReaLTaiizor.Controls.ForeverButton Btn_KillAll;
        public System.Windows.Forms.Panel Form_Header;
        public ReaLTaiizor.Controls.ForeverButton Btn_Close;
        public System.Windows.Forms.Panel Panel_P1;
        public System.Windows.Forms.Panel Panel_P2;
        public System.Windows.Forms.Panel Panel_P3;
        public System.Windows.Forms.Panel Panel_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel LBL_PlayerName;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel1;
        public ReaLTaiizor.Controls.MetroSwitch CB_zqinissofuckingsexy_P1;
        public ReaLTaiizor.Controls.MetroSwitch CB_Shoot_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel48;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rainbow_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel37;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel38;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleEnd_P1;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleStart_P1;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_P1;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib2_P1;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib_P1;
        public ReaLTaiizor.Controls.ForeverComboBox Box_TP_P1;
        public ReaLTaiizor.Controls.ForeverComboBox Box_Weapons_P1;
        public ReaLTaiizor.Controls.MetroSwitch CB_Cycle_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel39;
        public ReaLTaiizor.Controls.MetroSwitch CB_Croshair_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel40;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rapid_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel41;
        public ReaLTaiizor.Controls.MetroSwitch CB_Jail_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel42;
        public ReaLTaiizor.Controls.MetroSwitch CB_Crit_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel43;
        public ReaLTaiizor.Controls.MetroSwitch CB_Speed_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel44;
        public ReaLTaiizor.Controls.MetroSwitch CB_Ammo_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel45;
        public ReaLTaiizor.Controls.MetroSwitch CB_Points_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel46;
        public ReaLTaiizor.Controls.MetroSwitch CB_God_P1;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel47;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel31;
        public ReaLTaiizor.Controls.MetroSwitch CB_zqinissofuckingsexy_P2;
        public ReaLTaiizor.Controls.MetroSwitch CB_Shoot_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel32;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel33;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rainbow_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel34;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel35;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleEnd_P2;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleStart_P2;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_P2;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib2_P2;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib_P2;
        public ReaLTaiizor.Controls.ForeverComboBox Box_TP_P2;
        public ReaLTaiizor.Controls.ForeverComboBox Box_Weapons_P2;
        public ReaLTaiizor.Controls.MetroSwitch CB_Cycle_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel36;
        public ReaLTaiizor.Controls.MetroSwitch CB_Croshair_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel49;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rapid_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel50;
        public ReaLTaiizor.Controls.MetroSwitch CB_Jail_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel51;
        public ReaLTaiizor.Controls.MetroSwitch CB_Crit_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel52;
        public ReaLTaiizor.Controls.MetroSwitch CB_Speed_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel53;
        public ReaLTaiizor.Controls.MetroSwitch CB_Ammo_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel54;
        public ReaLTaiizor.Controls.MetroSwitch CB_Points_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel55;
        public ReaLTaiizor.Controls.MetroSwitch CB_God_P2;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel56;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel17;
        public ReaLTaiizor.Controls.MetroSwitch CB_zqinissofuckingsexy_P3;
        public ReaLTaiizor.Controls.MetroSwitch CB_Shoot_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel18;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel19;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rainbow_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel20;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel21;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleEnd_P3;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleStart_P3;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_P3;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib2_P3;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib_P3;
        public ReaLTaiizor.Controls.ForeverComboBox Box_TP_P3;
        public ReaLTaiizor.Controls.ForeverComboBox Box_Weapons_P3;
        public ReaLTaiizor.Controls.MetroSwitch CB_Cycle_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel22;
        public ReaLTaiizor.Controls.MetroSwitch CB_Croshair_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel23;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rapid_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel24;
        public ReaLTaiizor.Controls.MetroSwitch CB_Jail_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel25;
        public ReaLTaiizor.Controls.MetroSwitch CB_Crit_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel26;
        public ReaLTaiizor.Controls.MetroSwitch CB_Speed_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel27;
        public ReaLTaiizor.Controls.MetroSwitch CB_Ammo_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel28;
        public ReaLTaiizor.Controls.MetroSwitch CB_Points_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel29;
        public ReaLTaiizor.Controls.MetroSwitch CB_God_P3;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel30;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel3;
        public ReaLTaiizor.Controls.MetroSwitch CB_zqinissofuckingsexy_P4;
        public ReaLTaiizor.Controls.MetroSwitch CB_Shoot_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel5;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rainbow_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel6;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel7;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleEnd_P4;
        public ReaLTaiizor.Controls.ForeverComboBox Box_CycleStart_P4;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_P4;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib2_P4;
        public ReaLTaiizor.Controls.ForeverButton Btn_Gib_P4;
        public ReaLTaiizor.Controls.ForeverComboBox Box_TP_P4;
        public ReaLTaiizor.Controls.ForeverComboBox Box_Weapons_P4;
        public ReaLTaiizor.Controls.MetroSwitch CB_Cycle_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel8;
        public ReaLTaiizor.Controls.MetroSwitch CB_Croshair_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel9;
        public ReaLTaiizor.Controls.MetroSwitch CB_Rapid_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel10;
        public ReaLTaiizor.Controls.MetroSwitch CB_Jail_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel11;
        public ReaLTaiizor.Controls.MetroSwitch CB_Crit_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel12;
        public ReaLTaiizor.Controls.MetroSwitch CB_Speed_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel13;
        public ReaLTaiizor.Controls.MetroSwitch CB_Ammo_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel14;
        public ReaLTaiizor.Controls.MetroSwitch CB_Points_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel15;
        public ReaLTaiizor.Controls.MetroSwitch CB_God_P4;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel16;
        public ReaLTaiizor.Controls.MetroSwitch CB_TP_ZM;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel57;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_Set;
        public ReaLTaiizor.Controls.NightHeaderLabel LBL_Shots;
        public ReaLTaiizor.Controls.PoisonTrackBar Bar_Shots;
        public ReaLTaiizor.Controls.NightHeaderLabel LBL_Kills;
        public ReaLTaiizor.Controls.PoisonTrackBar Bar_Kills;
        public System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Timer timer2;
        public System.Windows.Forms.Timer timer3;
        public System.Windows.Forms.Timer timer4;
        public ReaLTaiizor.Controls.ForeverButton Btn_Dark;
        public ReaLTaiizor.Controls.ForeverButton Btn_Kill_multi;
        public ReaLTaiizor.Controls.ForeverButton Dtn_Diamond;
        public ReaLTaiizor.Controls.NightHeaderLabel LBL_Gun;
        public ReaLTaiizor.Controls.ForeverButton Btn_QuickDA;
        public ReaLTaiizor.Controls.ForeverButton Btn_TP_Bots;
        public ReaLTaiizor.Controls.MetroSwitch CB_Bots;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel58;
        public ReaLTaiizor.Controls.MetroSwitch CB_RoundSkip;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel60;
        private System.Windows.Forms.Label DAHelp;
        public ReaLTaiizor.Controls.MetroSwitch CB_Noclip;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel59;
        public ReaLTaiizor.Controls.PoisonTrackBar bar_noclip;
        public ReaLTaiizor.Controls.MetroSwitch CB_AutoKill;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel61;
        public System.Windows.Forms.Timer XP_Timer;
        public ReaLTaiizor.Controls.MetroSwitch CB_XP;
        public ReaLTaiizor.Controls.NightHeaderLabel nightHeaderLabel62;
    }
}

