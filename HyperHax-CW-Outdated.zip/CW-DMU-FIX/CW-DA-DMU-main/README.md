# CW-DA-DMU
Source to a popular tool made private for over a year

Took out the private Memory Class and Private Kernel Driver, so you will need to replace them with your own or use the logic!
if you are unsure how to do this please reply to the Cracked.to Thread


• Dark Aether Unlock (1SD Shoot one bullet from each category to unlock DA, all gold viper/diamond unlocked in under 10 seconds)
• Kill Multiplier (Each kill counts as 200, useful for unlocking camos in all categories)
• Auto Weapon Cycle (Will cycle weapon after x amount of kills/x amount of shots)
• Kill All Players and Reset Tool
• Quick Dark Aether Preset Settings (this will enable all the features you need to do a dark aether lobby without setting them yourself)

Player Options
• Godmode
• Unlimited Points
• Unlimited Ammo
• Rapid Fire
• Speed run
• 100% Critical's
• Weapon Cycle
• Give Weapon
• Teleport To Location
• Send Player to Jail
• TP Zombies to Crosshair
• Rainbow Gun Cycle

Lobby Options:
• Teleport Zombies and Set Location

DMU Soft Unlock (Included)
• Create a Customs Game Match
• Invite Players
• Remove time/score limit
• Add bots (after all players have joined, make sure to follow this correctly)
• Start Match
• Once spawned in turn on "Instant MP Diamond" (make sure its during the countdown while players cant move)
• Turn on Weapon Cycle, God Mode, Unlimited Ammo for each player
• Set Kill Cycle to 2
• Set Shots Cycle to 5000 (so guns wont swap from shots)
• Each player gets 2 kill per each of the first 9 guns (once they reach AK in cycle they are good)
• Press "Kill All and Reset" to disable everything
• End match
• Save Blueprints
